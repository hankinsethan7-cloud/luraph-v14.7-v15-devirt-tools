# Third-party notices

The optional Luau executable used as the decoder host is from the
[official Luau project](https://github.com/luau-lang/luau), copyright Roblox
Corporation, and distributed under the MIT License.

The deobfuscator does not redistribute Luau as part of its Python package. A
locally downloaded copy can be placed at `.tools/luau-0.722/luau.exe`, supplied
with `--luau`, or selected through `LUAU_PATH`.
