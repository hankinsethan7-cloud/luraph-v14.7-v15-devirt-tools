import os
from pathlib import Path

BOT_DIR = Path(__file__).resolve().parent
ENGINE_DIR = BOT_DIR / "engine" / "deobf"
MOONVEIL_DIR = (
    BOT_DIR
    / "engine"
    / "moonveil_vendor"
    / "Moonveil-1.4.5-Deobfuscator-main"
)
MOONSEC_DIR = (
    Path(os.environ["MOONSEC_DIR"]).expanduser()
    if os.environ.get("MOONSEC_DIR")
    else None
)
MAX_INPUT_MB = 25
MAX_INPUT_BYTES = MAX_INPUT_MB * 1_048_576
MAX_OUTPUT_BYTES = 25 * 1_048_576
ENGINE_TIMEOUT_SECONDS = 120
CREDIT_UNIT_BYTES = 1_048_576
RUNTIME_CREDIT_INTERVAL_SECONDS = 30
MAX_RUNTIME_CREDIT_RESERVE = ENGINE_TIMEOUT_SECONDS // RUNTIME_CREDIT_INTERVAL_SECONDS
BOT_OWNERS = frozenset(
    {
        1183142340609708072,
        1268381063101092592,
    }
)
BRAND = "discord.gg/printed"