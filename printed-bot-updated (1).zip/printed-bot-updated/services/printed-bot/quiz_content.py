from __future__ import annotations

import random

QuizQuestion = tuple[str, tuple[str, str, str], int]

QUIZ_QUESTIONS: tuple[QuizQuestion, ...] = (
    ("Which Lua line displays text?", ("console.log('Hello')", "print('Hello')", "echo 'Hello'"), 1),
    ("What does `local score = 3` do?", ("Creates a local variable named score", "Starts a loop", "Deletes score"), 0),
    ("Which operator checks whether two Lua values are equal?", ("=", "!=", "=="), 2),
    ("What value represents no value in Lua?", ("none", "nil", "null"), 1),
    ("How do you join two strings in Lua?", ("Use `..`", "Use `+`", "Use `&`"), 0),
    ("Which syntax starts a single-line Lua comment?", ("//", "--", "#"), 1),
    ("Which expression reads the first item in a Lua array-style table?", ("items[0]", "items.first", "items[1]"), 2),
    ("Which keyword sends a value back from a function?", ("give", "return", "yield"), 1),
    ("Which condition is true only when `ready` is true?", ("if ready then", "when ready do", "if (ready == yes)"), 0),
    ("Which loop counts from 1 through 3?", ("for i = 1, 3 do", "repeat i = 1, 3", "while i in 1..3"), 0),
    ("What does `#items` usually return for an array-like table?", ("The last value", "Its length", "Its first key"), 1),
    ("Which keyword adds another condition after an `if`?", ("otherwise", "elseif", "except"), 1),
    ("What does `false` represent?", ("A boolean false value", "An empty string", "A missing table key"), 0),
    ("Which function commonly loops over a table's keys and values?", ("pairs(table)", "keys(table)", "each(table)"), 0),
    ("Which function declaration is valid Lua?", ("function add(a, b)", "def add(a, b)", "fn add(a, b)"), 0),
    ("What does `math.floor(3.8)` return?", ("3", "4", "3.8"), 0),
    ("Which keyword ends a `for` loop body?", ("done", "end", "stop"), 1),
    ("What does `type(value)` return?", ("The value's type name", "The value's size", "The variable's scope"), 0),
    ("Which keyword negates a boolean expression?", ("not", "never", "no"), 0),
    ("What is a Lua table commonly used for?", ("A collection of values", "A comment block", "A function return only"), 0),
    ("What does `pcall` help with?", ("Running a call while catching errors", "Creating a coroutine", "Printing a table"), 0),
    ("Which syntax creates a table with two string values?", ('{"red", "blue"}', "['red', 'blue']", "table('red', 'blue')"), 0),
)


def sample_quiz_questions(count: int = 3) -> tuple[QuizQuestion, ...]:
    if count < 1 or count > len(QUIZ_QUESTIONS):
        raise ValueError("Question count must fit within the quiz question pool.")
    return tuple(random.sample(QUIZ_QUESTIONS, count))