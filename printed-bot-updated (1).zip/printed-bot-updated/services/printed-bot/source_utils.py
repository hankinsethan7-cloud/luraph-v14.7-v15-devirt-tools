from __future__ import annotations

import io
import re
from pathlib import PurePath

from config import BRAND, MAX_INPUT_BYTES, MAX_INPUT_MB

_LONG_LOADSTRING = re.compile(
    r"^\s*(?:return\s+)?loadstring\s*\(\s*\[(=*)\[(.*?)\]\1\]\s*\)\s*\(\s*\)\s*;?\s*$",
    re.DOTALL,
)
_QUOTED_LOADSTRING = re.compile(
    r"""^\s*(?:return\s+)?loadstring\s*\(\s*(['"])(.*?)\1\s*\)\s*\(\s*\)\s*;?\s*$""",
    re.DOTALL,
)
_HTTPGET_LOADSTRING = re.compile(
    r"""^\s*(?:return\s+)?loadstring\s*\(\s*(?:game\s*:\s*)?"""
    r"""(?:HttpGet|HttpGetAsync)\s*\(\s*(['"])(.*?)\1\s*"""
    r"""(?:,\s*(?:true|false)\s*)?\)\s*\)\s*(?:\(\s*\))?\s*;?\s*$""",
    re.IGNORECASE | re.DOTALL,
)
_DISCORD_INVITE = re.compile(
    r"""(?i)(?:https?://)?(?:www\.)?(?:discord\.gg|discordapp\.com/invite|"""
    r"""discord\.com/invite|dsc\.gg)/[A-Za-z0-9-]+(?:\?[^\s"'<>]*)?"""
)


class SourceInputError(ValueError):
    pass


def unwrap_loadstring(source: str) -> str:
    """Extract only static string payloads; never evaluate a Lua expression."""
    match = _LONG_LOADSTRING.match(source)
    if match:
        return match.group(2)

    match = _QUOTED_LOADSTRING.match(source)
    if match:
        value = match.group(2)
        return (
            value.replace(r"\n", "\n")
            .replace(r"\r", "\r")
            .replace(r"\t", "\t")
            .replace(r"\\", "\\")
            .replace(r"\"", '"')
            .replace(r"\'", "'")
        )

    return source


def extract_loadstring_url(source: str) -> str | None:
    """Return only a URL passed as a literal to game:HttpGet inside loadstring."""
    match = _HTTPGET_LOADSTRING.match(source)
    if not match:
        return None
    return (
        match.group(2)
        .replace(r"\/", "/")
        .replace(r"\:", ":")
        .replace(r"\?", "?")
        .replace(r"\&", "&")
        .replace(r"\\", "\\")
        .replace(r"\"", '"')
        .replace(r"\'", "'")
    )


def sanitize_discord_invites(value: str) -> str:
    """Replace invite URLs from other Discord communities with Printed's invite."""
    return _DISCORD_INVITE.sub(BRAND, value)


def decode_source(data: bytes, filename: str = "source.lua") -> str:
    if len(data) > MAX_INPUT_BYTES:
        raise SourceInputError(f"Files must be {MAX_INPUT_MB} MiB or smaller.")
    if b"\x00" in data:
        raise SourceInputError("That file contains binary data; upload a plain-text Lua/Luau source file.")

    for encoding in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            source = data.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise SourceInputError("I couldn't decode that file as text.")

    if not source.strip():
        raise SourceInputError("The source file is empty.")
    if len(source.encode("utf-8")) > MAX_INPUT_BYTES * 4:
        raise SourceInputError("The decoded source is too large to process.")
    return source


def clean_filename(filename: str, suffix: str) -> str:
    stem = PurePath(filename).stem or "source"
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", stem).strip("_-")[:64] or "source"
    return f"{stem}.{suffix}.lua"


def branded_output(source: str, origin: str) -> bytes:
    source = sanitize_discord_invites(source)
    origin = sanitize_discord_invites(origin)
    lines = source.splitlines()
    preview_lines = lines[:5] or ["(empty source)"]
    preview = [
        "-- done by /printed bot",
        f"-- {BRAND}",
        f"-- Source: {origin}",
        "-- Preview: first 5 lines of the source below",
    ]
    for index, line in enumerate(preview_lines, start=1):
        one_line = line.replace("\r", "").replace("\n", " ")
        if len(one_line) > 180:
            one_line = one_line[:177] + "..."
        preview.append(f"-- {index}: {one_line}")
    preview.extend(["", source.rstrip(), ""])
    return "\n".join(preview).encode("utf-8", errors="replace")


def make_file(payload: bytes, filename: str):
    return io.BytesIO(payload), filename