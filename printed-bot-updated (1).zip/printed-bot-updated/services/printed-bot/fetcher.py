from __future__ import annotations

import asyncio
import ipaddress
import socket
from urllib.parse import urljoin, urlsplit

import aiohttp

from config import MAX_INPUT_BYTES, MAX_INPUT_MB
from source_utils import (
    SourceInputError,
    decode_source,
    extract_loadstring_url,
    unwrap_loadstring,
)

_REDIRECT_STATUSES = {301, 302, 303, 307, 308}
_ALLOWED_PORTS = {80, 443}


class FetchError(ValueError):
    pass


class PinnedResolver(aiohttp.abc.AbstractResolver):
    def __init__(self, host: str, addresses: list[ipaddress.IPv4Address | ipaddress.IPv6Address]):
        self.host = host
        self.addresses = addresses

    async def resolve(
        self,
        host: str,
        port: int = 0,
        family: int = socket.AF_INET,
    ) -> list[dict[str, int | str]]:
        if host.lower().rstrip(".") != self.host.lower().rstrip("."):
            raise OSError("Unexpected hostname during URL resolution.")
        return [
            {
                "hostname": host,
                "host": str(address),
                "port": port,
                "family": socket.AF_INET6 if address.version == 6 else socket.AF_INET,
                "proto": 0,
                "flags": 0,
            }
            for address in self.addresses
            if family in (socket.AF_UNSPEC, socket.AF_INET6 if address.version == 6 else socket.AF_INET)
        ]

    async def close(self) -> None:
        return None


async def _validate_and_pin(url: str) -> tuple[str, list[ipaddress.IPv4Address | ipaddress.IPv6Address]]:
    try:
        parsed = urlsplit(url)
        scheme = parsed.scheme.lower()
        host = parsed.hostname
        port = parsed.port or (443 if scheme == "https" else 80)
    except ValueError as exc:
        raise FetchError("That URL is malformed.") from exc

    if scheme not in {"http", "https"} or not host:
        raise FetchError("Use a public http:// or https:// URL.")
    if parsed.username or parsed.password:
        raise FetchError("URLs containing a username or password are not allowed.")
    if port not in _ALLOWED_PORTS:
        raise FetchError("Only standard HTTP and HTTPS ports are allowed.")

    loop = asyncio.get_running_loop()
    try:
        records = await loop.getaddrinfo(
            host,
            port,
            family=socket.AF_UNSPEC,
            type=socket.SOCK_STREAM,
        )
    except OSError as exc:
        raise FetchError("I couldn't resolve that public host.") from exc

    addresses: list[ipaddress.IPv4Address | ipaddress.IPv6Address] = []
    for record in records:
        try:
            address = ipaddress.ip_address(record[4][0])
        except ValueError:
            continue
        if not address.is_global:
            raise FetchError("Links to private, local, or reserved network addresses are blocked.")
        if address not in addresses:
            addresses.append(address)
    if not addresses:
        raise FetchError("That host has no public network address.")

    return host, addresses


async def fetch_public_source(url: str) -> tuple[str, str]:
    """Fetch plain-text source from a public URL with redirect-by-redirect SSRF checks."""
    current_url = url.strip()
    for _ in range(6):
        host, addresses = await _validate_and_pin(current_url)
        resolver = PinnedResolver(host, addresses)
        connector = aiohttp.TCPConnector(resolver=resolver, use_dns_cache=False)
        timeout = aiohttp.ClientTimeout(total=15, connect=6, sock_read=8)
        try:
            async with aiohttp.ClientSession(
                connector=connector,
                timeout=timeout,
                headers={"User-Agent": "PrintedBot/1.0 (+https://discord.gg/printed)"},
                trust_env=False,
            ) as session:
                async with session.get(current_url, allow_redirects=False) as response:
                    if response.status in _REDIRECT_STATUSES:
                        location = response.headers.get("Location")
                        if not location:
                            raise FetchError("The link redirected without a destination.")
                        current_url = urljoin(current_url, location)
                        continue
                    if response.status != 200:
                        raise FetchError(f"The link returned HTTP {response.status}.")

                    declared_size = response.content_length
                    if declared_size is not None and declared_size > MAX_INPUT_BYTES:
                        raise FetchError(f"Fetched source must be {MAX_INPUT_MB} MiB or smaller.")

                    chunks: list[bytes] = []
                    total = 0
                    async for chunk in response.content.iter_chunked(64 * 1024):
                        total += len(chunk)
                        if total > MAX_INPUT_BYTES:
                            raise FetchError(f"Fetched source must be {MAX_INPUT_MB} MiB or smaller.")
                        chunks.append(chunk)
        except asyncio.TimeoutError as exc:
            raise FetchError("The link took too long to respond.") from exc
        except aiohttp.ClientError as exc:
            raise FetchError("I couldn't download source from that link.") from exc

        try:
            text = decode_source(b"".join(chunks), current_url)
        except SourceInputError as exc:
            raise FetchError(str(exc)) from exc
        return text, current_url

    raise FetchError("That link redirected too many times.")


async def resolve_fetch_input(source: str) -> tuple[str, str]:
    value = source.strip()
    origin: str | None = None
    fetched_urls: set[str] = set()

    # Follow only literal payloads and literal HttpGet URLs. Never evaluate Lua.
    for _ in range(5):
        url = extract_loadstring_url(value)
        candidate = unwrap_loadstring(value).strip()
        if url is None and candidate.lower().startswith(("https://", "http://")):
            url = candidate

        if url is None:
            if candidate == value and "loadstring" in value.lower():
                raise FetchError(
                    "I can only unwrap a literal loadstring or a static "
                    "loadstring(game:HttpGet('https://…')) URL. Dynamic expressions "
                    "are never executed."
                )
            if not candidate:
                raise FetchError("No source was supplied.")
            if len(candidate.encode("utf-8")) > MAX_INPUT_BYTES:
                raise FetchError(f"Source must be {MAX_INPUT_MB} MiB or smaller.")
            return candidate, f"fetched from {origin}" if origin else "pasted Lua/Luau or literal loadstring"

        if url in fetched_urls:
            raise FetchError("The loadstring URL chain loops back to a source already fetched.")
        fetched_urls.add(url)
        value, origin = await fetch_public_source(url)

    raise FetchError("The source contains too many nested loadstring URL wrappers.")