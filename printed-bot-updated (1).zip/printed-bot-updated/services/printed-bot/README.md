# Printed Deobfuscator Discord Bot

A Discord bot for detecting supported Luau obfuscators, deobfuscating supported uploads, and fetching plain-text source. Command responses use branded embeds/buttons; source files are delivered privately (ephemeral for slash commands, DM for dot commands).

## Supported engines

- MoonVeil v1.4.5 from the user-supplied MIT-licensed source bundle
- Luraph v14.7, v14.8, and v14.9 from the supplied RAR
- Luraph v15 from the supplied ZIP
- IronBrew 1
- MoonSec V3 through its upstream CLI when a separately licensed local copy is configured
- WeAreDevs and Wynfuscate are labeled “coming soon”

Detection can label unknown or unsupported input, but the bot will not claim that generic analysis is full deobfuscation. Devirtualization may still fail on a protected file the engine version does not understand. Engine output is checked for unresolved helper stubs and parsed with the bundled Luau validator before delivery. Runtime traces and trace-assisted candidates are clearly marked partial; a script-error trace is rejected from the full-deobfuscation path. The original MoonVeil license and third-party notices are retained in `engine/moonveil_vendor/`.

MoonSec V3 is not bundled: its supplied source-available license prohibits redistribution and derivative copies. Upstream project: **MoonSec V3 Deobfuscator by worstskid / sergei.dev**. To enable it, use a copy you are licensed to run, set `MOONSEC_DIR` to the checkout root (containing `moonsec/Lua/cli.lua`), and install Lua or set `LUA_BINARY` to the interpreter executable. The adapter invokes the upstream CLI and validates the result with the bundled Luau parser. Use the engine only for code you own or are authorized to analyze.

## Commands

Each command is available as a Discord slash command and as a dot-prefix command:

- `/detect` or `.detect` — inspect pasted source, a public URL, a static `loadstring(...)` wrapper, or one file.
- `/deobf` or `.deobf` — deobfuscate a supported file, pasted source, or a static loadstring URL. Uploads are capped at 25 MiB.
- `/l` or `.l` — statically extract string literals, constant `string.char`/numeric-byte data, and common base64, hex, or percent-encoded payloads. It does not execute source or charge credits; output is a bounded ZIP of recovered files and a report.
- `/envlog` or `.envlog` — create a local, partial environment trace for source. It records emulated Luau behavior only; it never reads host environment variables or secrets.
- `/engines` or `.engines` — list full engines and local diagnostics.
- `/fetch` or `.fetch` — fetch a public HTTP(S) source URL, unwrap a literal loadstring, or fetch a literal `game:HttpGet("https://…")` payload. Dynamic expressions are never evaluated.
- `/quiz` or `.quiz` — answer three randomized beginner Lua questions selected from a larger pool. Pass at least 2/3; failed attempts have a saved one-hour retry wait.
- `/help` or `.help` — show command and engine information.
- `/tokens` or `.tokens` — see your persistent credit balance.
- `/grant` or `.grant` — add credits. Restricted to the two owner IDs in `config.py`.
- `/shutdown` or `.shutdown` — pause all bot commands except `/turnon` without disconnecting the bot. Restricted to the configured owner IDs.
- `/turnon` or `.turnon` — resume bot commands. Restricted to the configured owner IDs.

New accounts start with 10 credits. Each started MiB of input costs 1 credit (minimum 1); each full 30 seconds of engine time costs 1 more credit. Up to four runtime credits are temporarily held before a run so the completed runtime charge can be collected exactly; unused holds are returned. Credits persist without a daily reset. Failed runs and undelivered outputs are fully refunded; a delivered partial trace is labeled partial and charged for the work performed. Existing unused bonus uses are converted into credits during the one-time database migration.

If no full engine matches, the bot distinguishes readable source from an unknown wrapper. Unknown wrappers can be sent to the bundled local behavior tracer or environment logger. Both run locally in a restricted Luau process; they are not AI or full deobfuscation and only record behavior reached during the isolated run.

## Setup

1. Install Python 3.13+ and CMake, Ninja, Git, and a C++ compiler.
2. Install the declared Python packages from the workspace root with `uv sync` (or use `services/printed-bot/requirements.txt` outside Replit).
3. Build the Linux Luau runtime (required by the supplied analysis engine):

   ```sh
   python services/printed-bot/engine/deobf/build_luau.py --portable
   ```

4. Add `DISCORD_BOT_TOKEN` as a Replit Secret. Never put the token in this source tree or in chat.
5. In the Discord Developer Portal, enable the **Message Content Intent** for dot-prefix commands. Invite the bot with the `bot` and `applications.commands` scopes and permissions to view/send messages, attach files, use application commands, and read uploaded attachments.
6. Run from the workspace root:

   ```sh
   python main.py
   ```

Slash commands are registered globally on startup; Discord may take a short time to show them. Prefix commands require Message Content Intent to be enabled in both the portal and the bot.

## Replit hosting

Discord bots need an always-running process. `/shutdown` is a persistent command lock, not a process shutdown; `/turnon` reopens commands while the bot remains connected. In this pnpm workspace, the production API service starts the bot worker alongside its health server when `NODE_ENV=production`. Publish the **API Server** artifact as a **Reserved VM**, not Autoscale. The development console workflow runs the bot directly with `python main.py`.

Keep `DISCORD_BOT_TOKEN` in Replit Secrets. The downloadable source ZIP excludes the machine-specific Luau executables; build them with the included script before running the bot if `engine/deobf/bin/luau` is not present. MoonVeil uses that local runtime and the bot's Luau AST parser; it does not require a remote service.

## Runtime and privacy notes

- Submitted Luau is handled by the supplied engine in a separate process with a wall-clock limit, resource limits, and a per-job temporary working directory. The local behavior tracer is also isolated; neither path sends source to an external analysis API.
- URL fetching blocks local/private/reserved IPs, pins DNS results per request, rejects non-HTTP(S) and nonstandard ports, checks each redirect, and caps downloads at 25 MiB.
- Outputs include `-- done by /printed bot`, `discord.gg/printed`, and a comment preview of the first five source lines.
- SQLite credit balances are stored at `services/printed-bot/data/tokens.sqlite3` by default. Set `BOT_DATABASE_PATH` to a persistent path when hosting.