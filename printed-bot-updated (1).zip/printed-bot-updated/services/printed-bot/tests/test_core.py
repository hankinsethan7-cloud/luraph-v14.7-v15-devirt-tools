from __future__ import annotations

import asyncio
import base64
from io import BytesIO
import os
import sqlite3
import sys
import tempfile
import unittest
import zipfile
from unittest.mock import AsyncMock, patch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from config import CREDIT_UNIT_BYTES, ENGINE_DIR, MAX_INPUT_BYTES  # noqa: E402
from engine_service import (  # noqa: E402
    EngineError,
    _command_for,
    _validate_engine_output,
    _validate_luau_input,
    detect_source,
)
from fetcher import FetchError, _validate_and_pin, resolve_fetch_input  # noqa: E402
from quota import QUALIFICATION_RETRY_SECONDS, TokenStore, estimate_credit_cost  # noqa: E402
from quiz_content import QUIZ_QUESTIONS, sample_quiz_questions  # noqa: E402
from source_utils import (  # noqa: E402
    SourceInputError,
    branded_output,
    decode_source,
    extract_loadstring_url,
    sanitize_discord_invites,
    unwrap_loadstring,
)
from static_dump import build_static_dump  # noqa: E402


class QuotaTests(unittest.TestCase):
    def test_persistent_credits_reserve_refund_and_runtime_settlement(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = TokenStore(Path(temporary) / "tokens.sqlite3")
            user_id = 12345

            self.assertEqual(store.status(user_id).credits, 10)
            reservation = store.reserve(user_id, amount=3)
            self.assertEqual(store.status(user_id).credits, 7)
            store.refund(reservation)
            store.refund(reservation)
            self.assertEqual(store.status(user_id).credits, 10)

            successful_run = store.reserve(user_id, amount=2, runtime_reserve=4)
            self.assertEqual(store.status(user_id).credits, 4)
            balance = store.settle(successful_run, 65.0)
            self.assertEqual(balance.credits, 6)
            store.refund(successful_run)
            self.assertEqual(store.status(user_id).credits, 6)
            self.assertIsNone(store.reserve(user_id, amount=3, runtime_reserve=4))
            self.assertEqual(TokenStore(Path(temporary) / "tokens.sqlite3").status(user_id).credits, 6)

    def test_existing_bonus_uses_are_preserved_as_credits_on_upgrade(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "tokens.sqlite3"
            connection = sqlite3.connect(database)
            try:
                connection.execute(
                    "CREATE TABLE user_tokens (user_id INTEGER PRIMARY KEY, bonus_tokens INTEGER NOT NULL DEFAULT 0)"
                )
                connection.execute(
                    "INSERT INTO user_tokens (user_id, bonus_tokens) VALUES (42, 3)"
                )
                connection.commit()
            finally:
                connection.close()
            upgraded = TokenStore(database)
            self.assertEqual(upgraded.status(42).credits, 13)

    def test_unfinished_reservations_are_refunded_after_restart(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "tokens.sqlite3"
            store = TokenStore(database)
            reservation = store.reserve(84, amount=2, runtime_reserve=4)
            self.assertEqual(store.status(84).credits, 4)

            restarted_store = TokenStore(database)
            self.assertEqual(restarted_store.status(84).credits, 10)
            restarted_store.refund(reservation)
            self.assertEqual(restarted_store.status(84).credits, 10)

    def test_command_shutdown_persists_and_can_be_turned_back_on(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "tokens.sqlite3"
            store = TokenStore(database)
            self.assertFalse(store.commands_shutdown())

            store.set_commands_shutdown(True)
            restarted_store = TokenStore(database)
            self.assertTrue(restarted_store.commands_shutdown())

            restarted_store.set_commands_shutdown(False)
            self.assertFalse(TokenStore(database).commands_shutdown())

    def test_credit_cost_scales_with_started_mebibytes_and_grants(self) -> None:
        self.assertEqual(estimate_credit_cost(1), 1)
        self.assertEqual(estimate_credit_cost(CREDIT_UNIT_BYTES), 1)
        self.assertEqual(estimate_credit_cost(CREDIT_UNIT_BYTES + 1), 2)
        with tempfile.TemporaryDirectory() as temporary:
            store = TokenStore(Path(temporary) / "tokens.sqlite3")
            self.assertEqual(store.grant(456, 4), 14)
            self.assertEqual(store.reserve(456, amount=15), None)

    def test_quiz_pool_randomizes_three_distinct_questions(self) -> None:
        selected = sample_quiz_questions()
        self.assertEqual(len(selected), 3)
        self.assertEqual(len(set(selected)), 3)
        self.assertTrue(all(question in QUIZ_QUESTIONS for question in selected))

    def test_quiz_pass_and_cooldown_persist(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "tokens.sqlite3"
            store = TokenStore(database)
            user_id = 777
            start = 1_800_000_000

            self.assertFalse(store.qualification_status(user_id, start).verified)
            failed = store.record_qualification_result(user_id, 1, start)
            self.assertFalse(failed.verified)
            self.assertEqual(failed.attempts, 1)
            self.assertEqual(failed.retry_at, start + QUALIFICATION_RETRY_SECONDS)

            restarted = TokenStore(database)
            self.assertEqual(
                restarted.qualification_status(
                    user_id,
                    start + QUALIFICATION_RETRY_SECONDS - 1,
                ).retry_at,
                start + QUALIFICATION_RETRY_SECONDS,
            )
            self.assertIsNone(
                restarted.qualification_status(
                    user_id,
                    start + QUALIFICATION_RETRY_SECONDS,
                ).retry_at
            )

            passed = restarted.record_qualification_result(
                user_id,
                2,
                start + QUALIFICATION_RETRY_SECONDS,
            )
            self.assertTrue(passed.verified)
            self.assertEqual(passed.attempts, 2)
            self.assertTrue(TokenStore(database).qualification_status(user_id).verified)


class SourceTests(unittest.TestCase):
    def test_static_loadstring_extraction_and_branding(self) -> None:
        source = "local x = 4\nprint(x)"
        self.assertEqual(unwrap_loadstring("loadstring([[" + source + "]])()"), source)
        self.assertEqual(unwrap_loadstring(r"""loadstring("print(\"ok\")")()"""), 'print("ok")')
        self.assertEqual(
            extract_loadstring_url(
                """loadstring(game:HttpGet("https://example.com/a.lua"))()"""
            ),
            "https://example.com/a.lua",
        )
        self.assertEqual(
            extract_loadstring_url(
                """loadstring(game:HttpGetAsync('https://example.com/b.lua', true))"""
            ),
            "https://example.com/b.lua",
        )
        self.assertIsNone(extract_loadstring_url("loadstring(game:HttpGet(url))()"))
        other_invite = "discord.gg/" + "not-printed"
        other_url = "https://" + other_invite
        self.assertEqual(
            sanitize_discord_invites(
                f"join {other_url}; Printed: discord.gg/printed"
            ),
            "join discord.gg/printed; Printed: discord.gg/printed",
        )
        alternate_invites = (
            "https://discordapp.com/invite/" + "not-printed",
            "https://discord.com/invite/" + "not-printed",
            "https://dsc.gg/" + "not-printed",
        )
        self.assertEqual(
            sanitize_discord_invites(" ".join(alternate_invites)),
            " ".join(("discord.gg/printed",) * len(alternate_invites)),
        )

        output = branded_output(
            "one\ntwo\nthree\nfour\nfive\nsix\n-- " + other_invite,
            other_url,
        )
        text = output.decode("utf-8")
        self.assertIn("-- done by /printed bot", text)
        self.assertIn("-- discord.gg/printed", text)
        self.assertIn("-- 5: five", text)
        self.assertNotIn("-- 6: six", text)
        self.assertNotIn("not-printed", text)

    def test_input_size_and_binary_checks(self) -> None:
        slightly_over_one_mib = b"x" * (1_048_576 + 1)
        self.assertEqual(len(decode_source(slightly_over_one_mib)), len(slightly_over_one_mib))
        with self.assertRaises(SourceInputError):
            decode_source(b"x" * (MAX_INPUT_BYTES + 1))
        with self.assertRaises(SourceInputError):
            decode_source(b"return \x00")


class StaticDumpTests(unittest.TestCase):
    def test_extracts_literals_encodings_and_constant_byte_builders(self) -> None:
        nested_source = b"local recovered = 'nested payload'"
        encoded_source = base64.b64encode(nested_source).decode("ascii")
        source = (
            "-- local hidden = 'comment-only value'\n"
            r'local escaped = "\072\101\108\108\111"' + "\n"
            f'local encoded = "{encoded_source}"\n'
            'local hex = "48656c6c6f20686578207061796c6f6164"\n'
            "local bytes = string.char(114,101,116,117,114,110,32,49)\n"
            "local array = {72,101,108,108,111,32,116,97,98,108,101}\n"
            'local joined = "join-" .. "one" .. "-done"\n'
        )

        result = build_static_dump(source, "sample.lua")
        self.assertGreater(result.findings, 8)
        with zipfile.ZipFile(BytesIO(result.archive)) as archive:
            report = archive.read("report.txt").decode("utf-8")
            payloads = [
                archive.read(name)
                for name in archive.namelist()
                if name.startswith("payloads/")
            ]

        self.assertIn("source code was not executed", report)
        self.assertTrue(any(b"Hello" in payload for payload in payloads))
        self.assertTrue(any(b"Hello hex payload" in payload for payload in payloads))
        self.assertTrue(any(b"return 1" in payload for payload in payloads))
        self.assertTrue(any(b"Hello table" in payload for payload in payloads))
        self.assertTrue(any(b"join-one-done" in payload for payload in payloads))
        self.assertTrue(any(b"nested payload" in payload for payload in payloads))
        self.assertFalse(any(b"comment-only value" in payload for payload in payloads))

    def test_marks_findings_truncated_at_safety_limit(self) -> None:
        source = "\n".join(f'local value_{index} = "payload-{index:04d}"' for index in range(400))
        result = build_static_dump(source)
        self.assertTrue(result.truncated)
        self.assertEqual(result.findings, 250)


class DetectionTests(unittest.TestCase):
    def test_supported_versions_and_coming_soon_engines(self) -> None:
        for version in ("14.7", "14.8", "14.9"):
            detected = detect_source(f"-- This file was protected using Luraph Obfuscator v{version}")
            self.assertEqual(detected.engine, version)
        self.assertEqual(detect_source("-- Luraph Obfuscator v15").engine, "15")
        headerless_v15 = (
            "\ufeff-- copied without the Luraph banner\n"
            "return setmetatable({ [75]=bit32.rrotate }, {})"
        )
        self.assertEqual(detect_source(headerless_v15).engine, "15")
        self.assertEqual(
            detect_source("-- this file was generated using ironbrew1").engine,
            "ironbrew1",
        )
        moonveil = detect_source("-- Protected by MoonVeil Obfuscator v1.4.5")
        self.assertEqual(moonveil.engine, "moonveil145")
        moonsec = detect_source(
            "-- This file was protected with MoonSec V3\nreturn function() end"
        )
        self.assertEqual(moonsec.engine, "moonsec_v3")
        self.assertIsNone(detect_source("-- Wynfuscate payload").engine)


class EngineCommandTests(unittest.TestCase):
    def test_moonsec_invokes_the_configured_upstream_cli(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cli = root / "moonsec" / "Lua" / "cli.lua"
            cli.parent.mkdir(parents=True)
            cli.write_text("-- test stub\n", encoding="utf-8")
            input_path = root / "input.lua"
            output_path = root / "output.lua"
            with (
                patch("engine_service.MOONSEC_DIR", root),
                patch("engine_service.shutil.which", return_value="/usr/bin/lua"),
                patch.dict(os.environ, {"LUA_BINARY": ""}),
            ):
                command = _command_for("moonsec_v3", input_path, output_path)

        self.assertEqual(
            command,
            ["/usr/bin/lua", str(cli), str(input_path), str(output_path)],
        )

    def test_moonsec_reports_when_external_source_is_not_configured(self) -> None:
        with patch("engine_service.MOONSEC_DIR", None):
            with self.assertRaisesRegex(EngineError, "MOONSEC_DIR"):
                _command_for("moonsec_v3", Path("input.lua"), Path("output.lua"))


class EngineOutputTests(unittest.TestCase):
    def test_luau_ast_rejects_an_unfinished_source_string(self) -> None:
        parser_name = "luau-ast.exe" if os.name == "nt" else "luau-ast"
        if not (ENGINE_DIR / "bin" / parser_name).is_file():
            self.skipTest("Build the bundled Luau tools before running parser validation tests.")
        with tempfile.TemporaryDirectory() as temporary:
            source_path = Path(temporary) / "input.lua"
            source_path.write_text('local source = "unfinished\n', encoding="utf-8")
            child_env = {"PATH": os.environ.get("PATH", "")}
            if os.environ.get("LD_LIBRARY_PATH"):
                child_env["LD_LIBRARY_PATH"] = os.environ["LD_LIBRARY_PATH"]
            with self.assertRaisesRegex(EngineError, "malformed or truncated"):
                _validate_luau_input(source_path, Path(temporary), child_env)

    def test_unresolved_luraph_stubs_are_rejected(self) -> None:
        output = (
            b"-- unresolved Luraph runtime helper; preserved as a safe stub\n"
            b"local function luraph_runtime1(...)\n\treturn nil\nend\n"
        )
        with self.assertRaisesRegex(EngineError, "result is incomplete"):
            _validate_engine_output(output)

    def test_trace_assisted_output_is_explicitly_partial(self) -> None:
        output = (
            b"-- Printed Bot result: partial trace-assisted reconstruction; "
            b"not full deobfuscation.\nprint('observed')\n"
        )
        self.assertTrue(_validate_engine_output(output))

    def test_trace_script_error_is_not_misreported_as_full_deobfuscation(self) -> None:
        output = (
            b"-- Local behavior trace only; not a complete deobfuscation.\n"
            b"-- run status: script error: invalid argument #1 to 'band'\n"
            b"print('before failure')\n"
        )
        with self.assertRaisesRegex(EngineError, "runtime trace"):
            _validate_engine_output(output)
        self.assertTrue(_validate_engine_output(output, allow_trace_errors=True))

    def test_stub_marker_takes_precedence_over_partial_marker(self) -> None:
        output = (
            b"-- Printed Bot result: partial trace-assisted reconstruction; "
            b"not full deobfuscation.\n"
            b"-- unresolved Luraph runtime helper\n"
        )
        with self.assertRaises(EngineError):
            _validate_engine_output(output)

    def test_normal_lua_is_not_mistaken_for_a_stub(self) -> None:
        self.assertFalse(_validate_engine_output(b"local helper = function() return nil end"))


class FetchSafetyTests(unittest.TestCase):
    def test_static_loadstring_httpget_is_fetched_without_evaluating_lua(self) -> None:
        async def check() -> None:
            with patch(
                "fetcher.fetch_public_source",
                new_callable=AsyncMock,
                return_value=("return 7", "https://example.com/code.lua"),
            ) as fetch:
                result = await resolve_fetch_input(
                    'loadstring(game:HttpGet("https://example.com/code.lua"))()'
                )
            self.assertEqual(result, ("return 7", "fetched from https://example.com/code.lua"))
            fetch.assert_awaited_once_with("https://example.com/code.lua")

        asyncio.run(check())

    def test_nested_static_loadstring_urls_are_bounded_and_followed(self) -> None:
        async def check() -> None:
            with patch(
                "fetcher.fetch_public_source",
                new_callable=AsyncMock,
                side_effect=[
                    (
                        "loadstring(game:HttpGet('https://example.com/second.lua'))()",
                        "https://example.com/first.lua",
                    ),
                    ("return 7", "https://example.com/second.lua"),
                ],
            ) as fetch:
                result = await resolve_fetch_input(
                    "loadstring([[https://example.com/first.lua]])()"
                )
            self.assertEqual(result, ("return 7", "fetched from https://example.com/second.lua"))
            self.assertEqual(
                [call.args[0] for call in fetch.await_args_list],
                [
                    "https://example.com/first.lua",
                    "https://example.com/second.lua",
                ],
            )

        asyncio.run(check())

    def test_dynamic_loadstring_expressions_are_rejected(self) -> None:
        async def check() -> None:
            with self.assertRaises(FetchError):
                await resolve_fetch_input("loadstring(game:HttpGet(url))()")

        asyncio.run(check())

    def test_private_hosts_are_rejected(self) -> None:
        async def check() -> None:
            with self.assertRaises(FetchError):
                await _validate_and_pin("http://127.0.0.1/")
            with self.assertRaises(FetchError):
                await _validate_and_pin("http://169.254.169.254/latest/meta-data/")
            with self.assertRaises(FetchError):
                await _validate_and_pin("file:///etc/passwd")

        asyncio.run(check())


if __name__ == "__main__":
    unittest.main()