from __future__ import annotations

import os
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from config import CREDIT_UNIT_BYTES, RUNTIME_CREDIT_INTERVAL_SECONDS

QUALIFICATION_RETRY_SECONDS = 60 * 60
MAX_CREDIT_BALANCE = 1_000_000


def estimate_credit_cost(input_bytes: int) -> int:
    if input_bytes < 1:
        raise ValueError("Input size must be at least one byte.")
    return max(1, (input_bytes + CREDIT_UNIT_BYTES - 1) // CREDIT_UNIT_BYTES)


@dataclass(frozen=True)
class TokenStatus:
    credits: int


@dataclass(frozen=True)
class Reservation:
    user_id: int
    amount: int
    runtime_reserve: int
    reservation_id: int


@dataclass(frozen=True)
class QualificationStatus:
    verified: bool
    attempts: int
    retry_at: int | None


class TokenStore:
    """Persistent size/runtime credit balance and qualification store."""

    def __init__(self, database_path: str | Path | None = None) -> None:
        configured = database_path or os.environ.get("BOT_DATABASE_PATH")
        self.path = Path(configured) if configured else Path(__file__).parent / "data" / "tokens.sqlite3"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS user_tokens (
                    user_id INTEGER PRIMARY KEY,
                    bonus_tokens INTEGER NOT NULL DEFAULT 0,
                    credits INTEGER NOT NULL DEFAULT 10
                )
                """
            )
            columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(user_tokens)")
            }
            if "credits" not in columns:
                connection.execute(
                    "ALTER TABLE user_tokens ADD COLUMN credits INTEGER NOT NULL DEFAULT 10"
                )
                # Preserve any unused bonus uses when upgrading the previous ledger.
                connection.execute(
                    "UPDATE user_tokens SET credits = 10 + bonus_tokens"
                )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS credit_reservations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    amount INTEGER NOT NULL,
                    runtime_reserved INTEGER NOT NULL DEFAULT 0,
                    runtime_charged INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'reserved'
                        CHECK (status IN ('reserved', 'settled', 'refunded')),
                    reserved_at INTEGER NOT NULL
                )
                """
            )
            reservation_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(credit_reservations)")
            }
            if "runtime_reserved" not in reservation_columns:
                connection.execute(
                    "ALTER TABLE credit_reservations "
                    "ADD COLUMN runtime_reserved INTEGER NOT NULL DEFAULT 0"
                )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS credit_reservations_user_status
                ON credit_reservations (user_id, status)
                """
            )
            # A process exit before delivery leaves only an uncompleted reservation.
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                UPDATE user_tokens
                SET credits = credits + (
                    SELECT COALESCE(SUM(amount + runtime_reserved), 0)
                    FROM credit_reservations
                    WHERE credit_reservations.user_id = user_tokens.user_id
                      AND credit_reservations.status = 'reserved'
                )
                WHERE user_id IN (
                    SELECT DISTINCT user_id
                    FROM credit_reservations
                    WHERE status = 'reserved'
                )
                """
            )
            connection.execute(
                "UPDATE credit_reservations SET status = 'refunded' WHERE status = 'reserved'"
            )
            connection.execute("COMMIT")
            # Retain the old rolling-use ledger during migration; it is no longer charged.
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS token_uses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    used_at INTEGER NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS token_uses_user_time ON token_uses (user_id, used_at)"
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS user_qualification (
                    user_id INTEGER PRIMARY KEY,
                    verified_at INTEGER,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    retry_at INTEGER
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS bot_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=15, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout=15000")
        try:
            yield connection
        finally:
            connection.close()

    def commands_shutdown(self) -> bool:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT value FROM bot_settings WHERE key = 'commands_shutdown'"
            ).fetchone()
        return row is not None and row["value"] == "1"

    def set_commands_shutdown(self, enabled: bool) -> None:
        if not isinstance(enabled, bool):
            raise ValueError("Command shutdown state must be a boolean.")
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO bot_settings (key, value)
                VALUES ('commands_shutdown', ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """,
                ("1" if enabled else "0",),
            )

    def status(self, user_id: int, now: int | None = None) -> TokenStatus:
        del now
        with self._connect() as connection:
            connection.execute(
                "INSERT OR IGNORE INTO user_tokens (user_id) VALUES (?)",
                (user_id,),
            )
            row = connection.execute(
                "SELECT credits FROM user_tokens WHERE user_id = ?",
                (user_id,),
            ).fetchone()
        return TokenStatus(row["credits"])

    def reserve(
        self,
        user_id: int,
        amount: int = 1,
        now: int | None = None,
        *,
        runtime_reserve: int = 0,
    ) -> Reservation | None:
        if isinstance(amount, bool) or amount < 1 or amount > MAX_CREDIT_BALANCE:
            raise ValueError(f"Reservation amount must be between 1 and {MAX_CREDIT_BALANCE}.")
        if (
            isinstance(runtime_reserve, bool)
            or runtime_reserve < 0
            or amount + runtime_reserve > MAX_CREDIT_BALANCE
        ):
            raise ValueError(f"Runtime reserve must fit within {MAX_CREDIT_BALANCE} credits.")
        total_reserved = amount + runtime_reserve
        current = int(time.time()) if now is None else int(now)
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "INSERT OR IGNORE INTO user_tokens (user_id) VALUES (?)",
                (user_id,),
            )
            row = connection.execute(
                "SELECT credits FROM user_tokens WHERE user_id = ?",
                (user_id,),
            ).fetchone()
            if row["credits"] < total_reserved:
                connection.execute("ROLLBACK")
                return None

            connection.execute(
                "UPDATE user_tokens SET credits = credits - ? WHERE user_id = ?",
                (total_reserved, user_id),
            )
            inserted = connection.execute(
                """
                INSERT INTO credit_reservations
                    (user_id, amount, runtime_reserved, reserved_at)
                VALUES (?, ?, ?, ?)
                """,
                (user_id, amount, runtime_reserve, current),
            )
            connection.execute("COMMIT")
            return Reservation(
                user_id,
                amount,
                runtime_reserve,
                int(inserted.lastrowid),
            )

    def refund(self, reservation: Reservation) -> None:
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            pending = connection.execute(
                """
                SELECT amount, runtime_reserved FROM credit_reservations
                WHERE id = ? AND user_id = ? AND status = 'reserved'
                """,
                (reservation.reservation_id, reservation.user_id),
            ).fetchone()
            if pending is not None:
                connection.execute(
                    "UPDATE user_tokens SET credits = credits + ? WHERE user_id = ?",
                    (
                        pending["amount"] + pending["runtime_reserved"],
                        reservation.user_id,
                    ),
                )
                connection.execute(
                    "UPDATE credit_reservations SET status = 'refunded' WHERE id = ?",
                    (reservation.reservation_id,),
                )
            connection.execute("COMMIT")

    def settle(self, reservation: Reservation, run_seconds: float) -> TokenStatus:
        """Keep size credits, charge full runtime intervals, and release unused hold."""
        runtime_cost = max(0, int(max(0.0, float(run_seconds)) // RUNTIME_CREDIT_INTERVAL_SECONDS))
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            pending = connection.execute(
                """
                SELECT id, runtime_reserved FROM credit_reservations
                WHERE id = ? AND user_id = ? AND status = 'reserved'
                """,
                (reservation.reservation_id, reservation.user_id),
            ).fetchone()
            if pending is None:
                connection.execute("ROLLBACK")
                return self.status(reservation.user_id)
            charged = min(pending["runtime_reserved"], runtime_cost)
            unused_runtime_reserve = pending["runtime_reserved"] - charged
            connection.execute(
                "UPDATE user_tokens SET credits = credits + ? WHERE user_id = ?",
                (unused_runtime_reserve, reservation.user_id),
            )
            connection.execute(
                """
                UPDATE credit_reservations
                SET status = 'settled', runtime_charged = ?
                WHERE id = ?
                """,
                (charged, reservation.reservation_id),
            )
            connection.execute("COMMIT")
        return self.status(reservation.user_id)

    def grant(self, user_id: int, amount: int) -> int:
        if amount < 1 or amount > 10_000:
            raise ValueError("Grant amount must be between 1 and 10,000.")

        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "INSERT OR IGNORE INTO user_tokens (user_id) VALUES (?)",
                (user_id,),
            )
            row = connection.execute(
                "SELECT credits FROM user_tokens WHERE user_id = ?",
                (user_id,),
            ).fetchone()
            updated = row["credits"] + amount
            if updated > MAX_CREDIT_BALANCE:
                connection.execute("ROLLBACK")
                raise ValueError("This user already has the maximum stored credit balance.")
            connection.execute(
                "UPDATE user_tokens SET credits = ? WHERE user_id = ?",
                (updated, user_id),
            )
            connection.execute("COMMIT")
            return updated

    def qualification_status(
        self,
        user_id: int,
        now: int | None = None,
    ) -> QualificationStatus:
        current = int(time.time()) if now is None else int(now)
        with self._connect() as connection:
            row = connection.execute(
                "SELECT verified_at, attempts, retry_at FROM user_qualification WHERE user_id = ?",
                (user_id,),
            ).fetchone()
        if row is None:
            return QualificationStatus(False, 0, None)
        retry_at = row["retry_at"]
        if retry_at is not None and retry_at <= current:
            retry_at = None
        return QualificationStatus(row["verified_at"] is not None, row["attempts"], retry_at)

    def record_qualification_result(
        self,
        user_id: int,
        score: int,
        now: int | None = None,
    ) -> QualificationStatus:
        if score < 0 or score > 3:
            raise ValueError("Quiz score must be between 0 and 3.")
        current = int(time.time()) if now is None else int(now)
        passed = score >= 2
        retry_at = None if passed else current + QUALIFICATION_RETRY_SECONDS

        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                INSERT INTO user_qualification (user_id, verified_at, attempts, retry_at)
                VALUES (?, ?, 1, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    verified_at = excluded.verified_at,
                    attempts = user_qualification.attempts + 1,
                    retry_at = excluded.retry_at
                """,
                (user_id, current if passed else None, retry_at),
            )
            connection.execute("COMMIT")

        return self.qualification_status(user_id, current)