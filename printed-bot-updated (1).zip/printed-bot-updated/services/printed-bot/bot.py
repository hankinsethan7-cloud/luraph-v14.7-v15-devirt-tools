from __future__ import annotations

import asyncio
import io
import logging
import os
import random
import re
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands

BOT_DIR = Path(__file__).resolve().parent
if str(BOT_DIR) not in sys.path:
    sys.path.insert(0, str(BOT_DIR))

from config import (  # noqa: E402
    BOT_OWNERS,
    BRAND,
    MAX_RUNTIME_CREDIT_RESERVE,
    MAX_INPUT_BYTES,
    MAX_INPUT_MB,
)
from engine_service import (  # noqa: E402
    Detection,
    EngineError,
    deobfuscate_sync,
    detect_source,
)
from fetcher import FetchError, resolve_fetch_input  # noqa: E402
from quota import (  # noqa: E402
    estimate_credit_cost,
    QualificationStatus,
    TokenStatus,
    TokenStore,
)
from quiz_content import sample_quiz_questions  # noqa: E402
from source_utils import (  # noqa: E402
    SourceInputError,
    branded_output,
    clean_filename,
    decode_source,
    extract_loadstring_url,
    sanitize_discord_invites,
    unwrap_loadstring,
)
from static_dump import StaticDumpError, build_static_dump  # noqa: E402

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("printed-bot")
token_store = TokenStore()


def _embed(title: str, description: str = "") -> discord.Embed:
    embed = discord.Embed(
        title=title,
        description=description,
        colour=discord.Colour.from_rgb(117, 90, 255),
    )
    embed.set_footer(text=f"{BRAND} • /help")
    return embed


def _help_embed() -> discord.Embed:
    embed = _embed(
        "Printed Bot · Commands",
        "Use a dot command in chat or the matching Discord slash command.",
    )
    embed.add_field(
        name="Inspect & transform",
        value=(
            "`/detect` or `.detect` — identify a known obfuscator\n"
            f"`/deobf` or `.deobf` — deobfuscate a supported upload ({MAX_INPUT_MB} MiB max)\n"
            f"`/l` or `.l` — statically extract strings and payloads ({MAX_INPUT_MB} MiB max)\n"
            "`/envlog` or `.envlog` — make a local, partial environment trace\n"
            "`/engines` or `.engines` — list supported engines\n"
            "`/fetch` or `.fetch` — fetch a public source URL or unwrap a literal loadstring"
        ),
        inline=False,
    )
    embed.add_field(
        name="Credits",
        value=(
            "`/tokens` or `.tokens` — view your persistent credit balance\n"
            "New users start with 10 credits. A run reserves 1 credit per started MiB and "
            f"temporarily holds up to {MAX_RUNTIME_CREDIT_RESERVE} runtime credits. "
            "It charges 1 per full 30 seconds; unused holds are returned. Failed runs are refunded."
        ),
        inline=False,
    )
    embed.add_field(
        name="First use",
        value=(
            "`/quiz` or `.quiz` — take a randomized 3-question beginner quiz from a larger pool. "
            "Pass at least 2/3; a failed attempt has a one-hour wait before retrying."
        ),
        inline=False,
    )
    embed.add_field(
        name="Owner tools",
        value=(
            "`/grant` or `.grant` — add credits (bot owners only)\n"
            "`/shutdown` or `.shutdown` — pause bot commands (bot owners only)\n"
            "`/turnon` or `.turnon` — resume bot commands (bot owners only)"
        ),
        inline=False,
    )
    embed.add_field(
        name="Engines",
        value=(
            "`/engines` lists availability. Supported: MoonVeil 1.4.5, Luraph 14.7, 14.8, "
            "14.9, 15, IronBrew 1, and MoonSec V3 when its licensed local engine is configured. "
            "Output is syntax-checked; incomplete candidates are never presented as complete. "
            "WeAreDevs and Wynfuscate are not supported yet."
        ),
        inline=False,
    )
    return embed


def _token_embed(user: discord.abc.User, status: TokenStatus) -> discord.Embed:
    embed = _embed(
        f"{user.display_name}'s credits",
        f"**Balance:** {status.credits}\n\n"
        f"Cost: 1 credit per started MiB, plus 1 credit per full 30 seconds of engine time. "
        f"Up to {MAX_RUNTIME_CREDIT_RESERVE} extra credits are temporarily held for runtime; "
        "unused holds are returned. Failed runs and undelivered files are refunded.",
    )
    return embed


async def _commands_active(interaction: discord.Interaction) -> bool:
    if not token_store.commands_shutdown():
        return True
    await interaction.response.send_message("BOT IS SHUT DOWN!", ephemeral=True)
    return False


active_quizzes: dict[int, CodeQuizView] = {}


class CodeQuizView(discord.ui.View):
    def __init__(self, owner_id: int):
        super().__init__(timeout=600)
        self.owner_id = owner_id
        self.questions = sample_quiz_questions()
        self.question_index = 0
        self.score = 0
        self.last_feedback = ""
        self._add_answers()

    def _add_answers(self) -> None:
        self.clear_items()
        _, options, _ = self.questions[self.question_index]
        for option_index, label in enumerate(options):
            button = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.secondary,
                row=0,
            )

            async def callback(
                interaction: discord.Interaction,
                selected_index: int = option_index,
            ) -> None:
                await self._answer(interaction, selected_index)

            button.callback = callback
            self.add_item(button)

    def _embed(self) -> discord.Embed:
        question, _, _ = self.questions[self.question_index]
        embed = _embed(
            f"Beginner code quiz · {self.question_index + 1}/{len(self.questions)}",
            f"{question}\n\nPass with at least **2 correct answers**. "
            "A failed attempt starts a one-hour retry wait.",
        )
        if self.last_feedback:
            embed.add_field(name="Previous answer", value=self.last_feedback, inline=False)
        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not await _commands_active(interaction):
            return False
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "This quiz belongs to the person who started it.",
                ephemeral=True,
            )
            return False
        return True

    async def _answer(self, interaction: discord.Interaction, selected_index: int) -> None:
        _, _, correct_index = self.questions[self.question_index]
        correct = selected_index == correct_index
        self.score += int(correct)
        self.last_feedback = "Correct." if correct else "Not quite."
        self.question_index += 1

        if self.question_index < len(self.questions):
            self._add_answers()
            await interaction.response.edit_message(embed=self._embed(), view=self)
            return

        result = token_store.record_qualification_result(self.owner_id, self.score)
        if active_quizzes.get(self.owner_id) is self:
            active_quizzes.pop(self.owner_id, None)
        self.clear_items()
        if result.verified:
            embed = _embed(
                "Quiz passed · commands unlocked",
                f"You got **{self.score}/{len(self.questions)}**. Your result is saved, "
                "so you do not need to repeat the quiz.",
            )
        else:
            retry = discord.utils.format_dt(
                datetime.fromtimestamp(result.retry_at or int(time.time()), UTC),
                style="R",
            )
            embed = _embed(
                "Quiz not passed yet",
                f"You got **{self.score}/{len(self.questions)}**. You can try again {retry}. "
                "Your retry time is saved if the bot restarts.",
            )
        await interaction.response.edit_message(embed=embed, view=None)

    async def on_timeout(self) -> None:
        if active_quizzes.get(self.owner_id) is self:
            active_quizzes.pop(self.owner_id, None)


class QuizPromptView(discord.ui.View):
    def __init__(self, owner_id: int):
        super().__init__(timeout=300)
        self.owner_id = owner_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not await _commands_active(interaction):
            return False
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "This setup prompt belongs to the person who opened it.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="Start the 3-question quiz", style=discord.ButtonStyle.primary)
    async def start_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        del button
        await _begin_quiz(interaction)


class PrintedButtons(discord.ui.View):
    def __init__(self, owner_id: int):
        super().__init__(timeout=180)
        self.owner_id = owner_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not await _commands_active(interaction):
            return False
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "These buttons belong to the person who opened this panel.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="Commands", style=discord.ButtonStyle.primary, emoji=None)
    async def commands_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        del button
        await interaction.response.send_message(embed=_help_embed(), ephemeral=True)

    @discord.ui.button(label="My credits", style=discord.ButtonStyle.secondary, emoji=None)
    async def tokens_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        del button
        status = token_store.status(interaction.user.id)
        await interaction.response.send_message(
            embed=_token_embed(interaction.user, status),
            ephemeral=True,
        )


class DeobfuscationActionView(discord.ui.View):
    def __init__(
        self,
        owner_id: int,
        source: str,
        filename: str,
        *,
        detection: Detection,
        local_trace: bool,
        output_to_dm: bool,
    ):
        super().__init__(timeout=300)
        self.owner_id = owner_id
        self.source = source
        self.filename = filename
        self.detection = detection
        self.local_trace = local_trace
        self.output_to_dm = output_to_dm
        self.children[0].label = (
            "Try local behavior trace" if local_trace else "Deobfuscate fetched code"
        )

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not await _commands_active(interaction):
            return False
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "This action belongs to the person who fetched the source.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="Try local behavior trace", style=discord.ButtonStyle.primary)
    async def run_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        del button
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)
        await _run_interaction_job(
            interaction,
            self.source,
            self.filename,
            detection=self.detection,
            local_trace=self.local_trace,
            environment_log=False,
            output_to_dm=self.output_to_dm,
        )

    @discord.ui.button(
        label="Local environment log",
        style=discord.ButtonStyle.secondary,
    )
    async def environment_log_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        del button
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)
        await _run_interaction_job(
            interaction,
            self.source,
            self.filename,
            detection=self.detection,
            local_trace=False,
            environment_log=True,
            output_to_dm=self.output_to_dm,
        )


class PrintedCommandTree(app_commands.CommandTree):
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        command = interaction.command
        if command is not None and token_store.commands_shutdown() and command.name not in {
            "turnon",
        }:
            await interaction.response.send_message("BOT IS SHUT DOWN!", ephemeral=True)
            return False
        if command is None or command.name in {
            "help",
            "quiz",
            "engines",
            "shutdown",
            "turnon",
        }:
            return True
        status = token_store.qualification_status(interaction.user.id)
        if status.verified:
            return True
        await _send_quiz_gate(interaction, status)
        return False


class PrintedBot(commands.Bot):
    async def can_run(
        self,
        ctx: commands.Context,
        *,
        call_once: bool = False,
    ) -> bool:
        if not await super().can_run(ctx, call_once=call_once):
            return False
        if (
            ctx.command is not None
            and token_store.commands_shutdown()
            and ctx.command.name != "turnon"
        ):
            await _reply(ctx, content="BOT IS SHUT DOWN!")
            return False
        if ctx.command is None or ctx.command.name in {
            "help",
            "quiz",
            "engines",
            "shutdown",
            "turnon",
        }:
            return True
        status = token_store.qualification_status(ctx.author.id)
        if status.verified:
            return True
        await _send_quiz_gate(ctx, status)
        return False

    async def setup_hook(self) -> None:
        synced = await self.tree.sync()
        logger.info("Registered %d global application commands.", len(synced))


intents = discord.Intents.default()
intents.message_content = True
bot = PrintedBot(
    command_prefix=".",
    intents=intents,
    help_command=None,
    tree_cls=PrintedCommandTree,
)


def _normalise_detection(detection: Detection) -> str:
    confidence = f"{detection.confidence:.0%}"
    if detection.engine == "moonsec_v3":
        status = "External engine; requires a licensed install, MOONSEC_DIR, and Lua"
    elif detection.supported:
        status = "Engine available; compatibility is checked for each input"
    elif detection.name in {"Wynfuscate", "WeAreDevs"}:
        status = "Coming soon"
    else:
        status = "No full engine available"
    note = f"\n{detection.note}" if detection.note else ""
    return f"**{detection.name}** · {confidence} confidence\n{status}{note}"


def _interaction_context(ctx: commands.Context) -> discord.Interaction | None:
    return ctx.interaction


async def _reply(
    ctx: commands.Context,
    *,
    content: str | None = None,
    embed: discord.Embed | None = None,
    view: discord.ui.View | None = None,
) -> None:
    interaction = _interaction_context(ctx)
    if interaction is None:
        await ctx.reply(content=content, embed=embed, view=view, mention_author=False)
    elif interaction.response.is_done():
        await interaction.followup.send(
            content=content,
            embed=embed,
            view=view,
            ephemeral=True,
        )
    else:
        await interaction.response.send_message(
            content=content,
            embed=embed,
            view=view,
            ephemeral=True,
        )


async def _send_quiz_gate(
    target: commands.Context | discord.Interaction,
    status: QualificationStatus,
) -> None:
    user_id = target.user.id if isinstance(target, discord.Interaction) else target.author.id
    if status.retry_at is not None:
        retry = discord.utils.format_dt(datetime.fromtimestamp(status.retry_at, UTC), style="R")
        embed = _embed(
            "Quiz retry wait",
            f"You can retry the beginner quiz {retry}. The wait is saved across bot restarts.",
        )
        view = None
    else:
        embed = _embed(
            "Take the quick setup quiz",
            "Before using bot commands, answer three beginner Lua questions. "
            "Pass at least **2/3**. If you miss the score, you can retry after one hour.",
        )
        view = QuizPromptView(user_id)

    if isinstance(target, discord.Interaction):
        if target.response.is_done():
            await target.followup.send(embed=embed, view=view, ephemeral=True)
        else:
            await target.response.send_message(embed=embed, view=view, ephemeral=True)
    else:
        await _reply(target, embed=embed, view=view)


async def _begin_quiz(interaction: discord.Interaction) -> None:
    user_id = interaction.user.id
    status = token_store.qualification_status(user_id)
    if status.verified:
        embed = _embed("Already verified", "Your quiz result is saved; all commands are unlocked.")
        view = None
    elif status.retry_at is not None:
        retry = discord.utils.format_dt(datetime.fromtimestamp(status.retry_at, UTC), style="R")
        embed = _embed("Quiz retry wait", f"You can try again {retry}.")
        view = None
    elif user_id in active_quizzes:
        embed = _embed("Quiz already started", "Finish the private quiz message that is already open.")
        view = None
    else:
        view = CodeQuizView(user_id)
        active_quizzes[user_id] = view
        embed = view._embed()

    try:
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, view=view, ephemeral=True)
        else:
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    except Exception:
        if view is not None and active_quizzes.get(user_id) is view:
            active_quizzes.pop(user_id, None)
        raise


async def _defer(ctx: commands.Context) -> None:
    interaction = _interaction_context(ctx)
    if interaction is not None and not interaction.response.is_done():
        await interaction.response.defer(ephemeral=True, thinking=True)


def _prefix_text(ctx: commands.Context) -> str:
    message = ctx.message.content
    prefix = ctx.prefix or "."
    invoked = ctx.invoked_with or ""
    return message[len(prefix) + len(invoked) :].strip()


def _decode_engine_text(payload: bytes) -> str:
    try:
        return payload.decode("utf-8-sig")
    except UnicodeDecodeError:
        return payload.decode("latin-1")


async def _read_command_input(
    ctx: commands.Context,
    source: str | None,
    attachment: discord.Attachment | None,
) -> tuple[str, str]:
    interaction = _interaction_context(ctx)
    if interaction is None:
        source = _prefix_text(ctx)
        if source.startswith("```") and source.endswith("```"):
            source = source[3:-3].strip()
            if source.lower().startswith(("lua\n", "luau\n")):
                source = source.split("\n", 1)[1]
    selected = attachment
    if selected is None and interaction is None and ctx.message.attachments:
        if len(ctx.message.attachments) > 1:
            raise SourceInputError("Please upload one source file per command.")
        selected = ctx.message.attachments[0]

    if selected is not None and source and source.strip():
        raise SourceInputError("Send either a file or pasted source, not both.")

    if selected is not None:
        if selected.size > MAX_INPUT_BYTES:
            raise SourceInputError(f"Files must be {MAX_INPUT_MB} MiB or smaller.")
        try:
            data = await selected.read()
        except discord.HTTPException as exc:
            raise SourceInputError("I couldn't read that Discord attachment.") from exc
        return decode_source(data, selected.filename), selected.filename

    if source and source.strip():
        if len(source.encode("utf-8")) > MAX_INPUT_BYTES:
            raise SourceInputError(f"Source must be {MAX_INPUT_MB} MiB or smaller.")
        return source.strip(), "pasted.lua"

    raise SourceInputError("Attach a Lua/Luau file or paste source after the command.")


def _preview_text(source: str) -> str:
    lines = source.splitlines()[:5]
    preview = "\n".join(lines) if lines else "(no lines)"
    preview = preview.replace("```", "'''")
    if len(preview) > 850:
        preview = preview[:847] + "..."
    return f"```lua\n{preview}\n```"


def _looks_like_plain_lua(source: str) -> bool:
    code = re.sub(r"--[^\n]*", "", source)
    lowered = code.lower()
    if not code.strip():
        return bool(re.search(r"^\s*--", source, re.MULTILINE))
    obfuscation_markers = (
        "string.char",
        "bit32.",
        "setmetatable({",
        "loadstring(",
        "getfenv(",
        "newproxy(",
    )
    if any(marker in lowered for marker in obfuscation_markers):
        return False
    if re.search(r"""['"][A-Za-z0-9+/=]{160,}['"]""", code):
        return False
    lines = [line for line in code.splitlines() if line.strip()]
    if len(lines) <= 4 and any(len(line) > 500 for line in lines):
        return False
    if code.strip() and len(code) <= 1_000 and len(lines) <= 20:
        return True
    return bool(re.search(r"\b(print|local|function|return|if|for|while)\b", code, re.IGNORECASE))


def _progress_embed(
    detection: Detection,
    started_at: datetime,
    elapsed: float,
    *,
    local_trace: bool,
    environment_log: bool = False,
) -> discord.Embed:
    if environment_log:
        title = "Local environment log running"
        action = (
            "Recording Luau behavior through a restricted local proxy. "
            "This does not read host environment variables or secrets."
        )
    elif local_trace:
        title = "Local behavior trace running"
        action = "Tracing the branches the script reaches in an isolated Luau environment."
    else:
        title = "Deobfuscation running"
        action = "Running the detected engine and validating its output."
    embed = _embed(title, action)
    embed.add_field(name="Detected", value=detection.name, inline=True)
    embed.add_field(
        name="Confidence",
        value=f"{detection.confidence:.0%}",
        inline=True,
    )
    embed.add_field(name="Elapsed", value=f"{elapsed:.1f}s", inline=True)
    embed.add_field(
        name="Started",
        value=discord.utils.format_dt(started_at, style="F"),
        inline=False,
    )
    return embed


async def _send_progress(
    ctx: commands.Context,
    embed: discord.Embed,
) -> discord.Message | discord.WebhookMessage:
    interaction = _interaction_context(ctx)
    if interaction is not None:
        return await interaction.followup.send(embed=embed, ephemeral=True, wait=True)
    return await ctx.reply(embed=embed, mention_author=False)


async def _edit_progress(
    message: discord.Message | discord.WebhookMessage,
    embed: discord.Embed,
    *,
    view: discord.ui.View | None = None,
) -> None:
    try:
        await message.edit(embed=embed, view=view)
    except discord.HTTPException:
        logger.debug("Could not update a progress message.", exc_info=True)


async def _run_engine_task(
    source: str,
    filename: str,
    detection: Detection,
    progress_message: discord.Message | discord.WebhookMessage,
    started_at: datetime,
    *,
    local_trace: bool,
    environment_log: bool = False,
) -> tuple[bytes, Detection, float, datetime]:
    started = time.monotonic()
    task = asyncio.create_task(
        asyncio.to_thread(
            deobfuscate_sync,
            source,
            filename,
            allow_generic_trace=local_trace,
            environment_log=environment_log,
        )
    )
    while True:
        done, _ = await asyncio.wait({task}, timeout=5)
        elapsed = time.monotonic() - started
        if done:
            break
        await _edit_progress(
            progress_message,
            _progress_embed(
                detection,
                started_at,
                elapsed,
                local_trace=local_trace,
                environment_log=environment_log,
            ),
        )
    output, actual_detection, engine_run_seconds = await task
    completed_at = datetime.now(UTC)
    return output, actual_detection, engine_run_seconds, completed_at


def _output_embed(
    title: str,
    source_text: str,
    detected: Detection | None,
    *,
    started_at: datetime | None = None,
    completed_at: datetime | None = None,
    run_seconds: float | None = None,
) -> discord.Embed:
    embed = _embed(title)
    if detected:
        embed.add_field(name="Detected", value=detected.name, inline=True)
        embed.add_field(
            name="Confidence",
            value=f"{detected.confidence:.0%}",
            inline=True,
        )
        if detected.partial:
            embed.add_field(
                name="Result quality",
                value=detected.note or "Trace-assisted candidate; not a full deobfuscation.",
                inline=False,
            )
    if run_seconds is not None:
        embed.add_field(name="Run time", value=f"{run_seconds:.2f}s", inline=True)
    if started_at is not None:
        embed.add_field(
            name="Started",
            value=discord.utils.format_dt(started_at, style="F"),
            inline=True,
        )
    if completed_at is not None:
        embed.add_field(
            name="Completed",
            value=discord.utils.format_dt(completed_at, style="F"),
            inline=True,
        )
    embed.add_field(
        name="Preview · first 5 lines",
        value=_preview_text(sanitize_discord_invites(source_text)),
        inline=False,
    )
    embed.add_field(name="Brand", value=BRAND, inline=True)
    return embed


async def _deliver_output(
    ctx: commands.Context,
    *,
    filename: str,
    payload: bytes,
    title: str,
    source_text: str,
    detected: Detection | None = None,
    started_at: datetime | None = None,
    completed_at: datetime | None = None,
    run_seconds: float | None = None,
    view: discord.ui.View | None = None,
) -> bool:
    source_text = sanitize_discord_invites(source_text)
    embed = _output_embed(
        title,
        source_text,
        detected,
        started_at=started_at,
        completed_at=completed_at,
        run_seconds=run_seconds,
    )
    file = discord.File(io.BytesIO(payload), filename=filename)
    interaction = _interaction_context(ctx)

    if interaction is not None:
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, file=file, view=view, ephemeral=True)
        else:
            await interaction.response.send_message(embed=embed, file=file, view=view, ephemeral=True)
        return True

    try:
        await ctx.author.send(embed=embed, file=file, view=view)
    except discord.Forbidden:
        await ctx.reply(
            "I couldn't DM the output. Enable DMs from server members, then run the command again.",
            mention_author=False,
        )
        return False
    else:
        await ctx.reply("Finished. I sent the source file to your DMs.", mention_author=False)
        return True


async def _run_deobfuscation(
    ctx: commands.Context,
    source: str,
    filename: str,
    *,
    environment_log: bool = False,
) -> None:
    source = sanitize_discord_invites(unwrap_loadstring(source))
    detection = detect_source(source)
    if not detection.supported and not environment_log:
        if _looks_like_plain_lua(source):
            plain_responses = (
                "Bro, this isn't obfuscated; it's already readable.",
                "Nothing to unwrap here. This Lua is already in the clear.",
                "The engine sees ordinary Lua, not a supported obfuscation wrapper.",
                "This file came in plain. The deobfuscator has nothing to do.",
            )
            readable_embed = _embed(
                "This already looks like readable Lua/Luau",
                f"{random.choice(plain_responses)} Use `/detect` if you expected an obfuscator.",
            )
            readable_embed.add_field(
                name="No run needed",
                value="I didn’t run an engine or charge credits for this file.",
                inline=False,
            )
            await _reply(
                ctx,
                embed=readable_embed,
            )
            return
        view = DeobfuscationActionView(
            ctx.author.id,
            source,
            filename,
            detection=detection,
            local_trace=True,
            output_to_dm=ctx.interaction is None,
        )
        await _reply(
            ctx,
            embed=_embed(
                "No full engine for this source",
                _normalise_detection(detection)
                + "\n\nYou can try a **local behavior trace**. It is not AI or full "
                "deobfuscation; it records the branches reached in a restricted Luau run. "
                "A separate local environment log is also available.",
            ),
            view=view,
        )
        return

    credit_cost = estimate_credit_cost(len(source.encode("utf-8")))
    reservation = token_store.reserve(
        ctx.author.id,
        amount=credit_cost,
        runtime_reserve=MAX_RUNTIME_CREDIT_RESERVE,
    )
    if reservation is None:
        await _reply(
            ctx,
            embed=_token_embed(ctx.author, token_store.status(ctx.author.id)),
        )
        return

    progress_message: discord.Message | discord.WebhookMessage | None = None
    started_at = datetime.now(UTC)
    try:
        await _defer(ctx)
        progress_message = await _send_progress(
            ctx,
            _progress_embed(
                detection,
                started_at,
                0,
                local_trace=False,
                environment_log=environment_log,
            ),
        )
        output, actual_detection, run_seconds, completed_at = await _run_engine_task(
            source,
            filename,
            detection,
            progress_message,
            started_at,
            local_trace=False,
            environment_log=environment_log,
        )
        decoded = sanitize_discord_invites(_decode_engine_text(output))
        partial_result = actual_detection.partial
        if environment_log:
            title = "Local environment log · partial"
            origin = f"partial local environment log for {actual_detection.name}"
        elif partial_result:
            title = "Partial trace-assisted result"
            origin = f"partial trace-assisted reconstruction for {actual_detection.name}"
        else:
            title = "Deobfuscation complete"
            origin = f"deobfuscated with {actual_detection.name}"
        packaged = branded_output(decoded, origin)
        delivered = await _deliver_output(
            ctx,
            filename=clean_filename(
                filename,
                "envlog" if environment_log else "partial" if partial_result else "deobf",
            ),
            payload=packaged,
            title=title,
            source_text=decoded,
            detected=actual_detection,
            started_at=started_at,
            completed_at=completed_at,
            run_seconds=run_seconds,
        )
        if not delivered:
            token_store.refund(reservation)
            await _edit_progress(
                progress_message,
                _embed(
                    "Output not delivered · credits refunded",
                    "Enable DMs from server members, then run the command again.",
                ),
            )
        else:
            balance = token_store.settle(reservation, run_seconds)
            await _edit_progress(
                progress_message,
                _embed(
                    "Local environment log sent · partial"
                    if environment_log
                    else "Partial result sent · credits charged"
                    if partial_result
                    else "Deobfuscation complete",
                    f"Finished in **{run_seconds:.2f}s**. "
                    f"Remaining balance: **{balance.credits} credits**. "
                    f"Completed {discord.utils.format_dt(completed_at, style='R')}.",
                ),
            )
    except EngineError as exc:
        token_store.refund(reservation)
        logger.warning("Deobfuscation failed for user %s: %s", ctx.author.id, exc)
        failure = _embed("Deobfuscation failed · credits refunded", str(exc)[:3_800])
        if progress_message is not None:
            await _edit_progress(progress_message, failure)
        else:
            await _reply(ctx, embed=failure)
    except Exception:
        token_store.refund(reservation)
        logger.exception("Unexpected deobfuscation failure for user %s.", ctx.author.id)
        failure = _embed(
            "Something went wrong · credits refunded",
            "The engine failed unexpectedly. Please try again with a smaller file.",
        )
        if progress_message is not None:
            await _edit_progress(progress_message, failure)
        else:
            await _reply(ctx, embed=failure)


async def _run_interaction_job(
    interaction: discord.Interaction,
    source: str,
    filename: str,
    *,
    detection: Detection,
    local_trace: bool,
    environment_log: bool,
    output_to_dm: bool,
) -> None:
    user_id = interaction.user.id
    credit_cost = estimate_credit_cost(len(source.encode("utf-8")))
    reservation = token_store.reserve(
        user_id,
        amount=credit_cost,
        runtime_reserve=MAX_RUNTIME_CREDIT_RESERVE,
    )
    response_private = interaction.guild_id is not None or not output_to_dm
    if reservation is None:
        await interaction.followup.send(
            embed=_token_embed(interaction.user, token_store.status(user_id)),
            ephemeral=response_private,
        )
        return

    started_at = datetime.now(UTC)
    progress_message: discord.Message | discord.WebhookMessage | None = None
    try:
        progress_message = await interaction.followup.send(
            embed=_progress_embed(
                detection,
                started_at,
                0,
                local_trace=local_trace,
                environment_log=environment_log,
            ),
            ephemeral=response_private,
            wait=True,
        )
        output, actual_detection, run_seconds, completed_at = await _run_engine_task(
            source,
            filename,
            detection,
            progress_message,
            started_at,
            local_trace=local_trace,
            environment_log=environment_log,
        )
        decoded = sanitize_discord_invites(_decode_engine_text(output))
        partial_result = actual_detection.partial
        if environment_log:
            title = "Local environment log · partial"
            origin = f"partial local environment log for {actual_detection.name}"
        elif local_trace:
            title = "Local behavior trace · partial"
            origin = f"partial local behavior trace for {actual_detection.name}"
        elif partial_result:
            title = "Partial trace-assisted result"
            origin = f"partial trace-assisted reconstruction for {actual_detection.name}"
        else:
            title = "Deobfuscation complete"
            origin = f"deobfuscated with {actual_detection.name}"
        embed = _output_embed(
            title,
            decoded,
            actual_detection,
            started_at=started_at,
            completed_at=completed_at,
            run_seconds=run_seconds,
        )
        file = discord.File(
            io.BytesIO(branded_output(decoded, origin)),
            filename=clean_filename(
                filename,
                "envlog"
                if environment_log
                else "trace"
                if local_trace
                else "partial"
                if partial_result
                else "deobf",
            ),
        )
        try:
            if output_to_dm:
                await interaction.user.send(embed=embed, file=file)
            else:
                await interaction.followup.send(
                    embed=embed,
                    file=file,
                    ephemeral=response_private,
                )
        except discord.Forbidden:
            token_store.refund(reservation)
            await _edit_progress(
                progress_message,
                _embed(
                    "Output not delivered · credits refunded",
                    "I couldn't DM the file. Enable DMs from server members, then retry.",
                ),
            )
            return

        balance = token_store.settle(reservation, run_seconds)
        if environment_log:
            done_title = "Environment log sent · partial"
            done_description = (
                "This is a local proxy trace, not full deobfuscation. "
                f"Remaining balance: **{balance.credits} credits**."
            )
        elif local_trace or partial_result:
            done_title = "Partial result sent · credits charged"
            done_description = (
                "This output is a partial trace, not full deobfuscation. "
                f"Remaining balance: **{balance.credits} credits**."
            )
        else:
            done_title = "Deobfuscation complete"
            done_description = (
                f"Finished in **{run_seconds:.2f}s**. "
                f"Remaining balance: **{balance.credits} credits**. "
                f"Completed {discord.utils.format_dt(completed_at, style='R')}."
            )
        await _edit_progress(
            progress_message,
            _embed(done_title, done_description),
        )
    except EngineError as exc:
        token_store.refund(reservation)
        logger.warning("Interaction engine run failed for user %s: %s", user_id, exc)
        failure = _embed("Analysis failed · credits refunded", str(exc)[:3_800])
        if progress_message is not None:
            await _edit_progress(progress_message, failure)
        else:
            await interaction.followup.send(embed=failure, ephemeral=response_private)
    except Exception:
        token_store.refund(reservation)
        logger.exception("Unexpected interaction engine failure for user %s.", user_id)
        failure = _embed(
            "Analysis failed · credits refunded",
            "The engine failed unexpectedly. Please try again with a smaller file.",
        )
        if progress_message is not None:
            await _edit_progress(progress_message, failure)
        else:
            await interaction.followup.send(embed=failure, ephemeral=response_private)


@bot.hybrid_command(name="help", description="Show Printed Bot commands and engine availability.")
async def help_command(ctx: commands.Context) -> None:
    status = token_store.qualification_status(ctx.author.id)
    if not status.verified:
        await _send_quiz_gate(ctx, status)
        return
    await _reply(ctx, embed=_help_embed(), view=PrintedButtons(ctx.author.id))


@bot.hybrid_command(
    name="quiz",
    description="Take the required beginner Lua quiz to unlock bot commands.",
)
async def quiz_command(ctx: commands.Context) -> None:
    status = token_store.qualification_status(ctx.author.id)
    if status.verified:
        await _reply(ctx, embed=_embed("Already verified", "Your quiz result is saved; all commands are unlocked."))
        return
    if status.retry_at is not None:
        retry = discord.utils.format_dt(datetime.fromtimestamp(status.retry_at, UTC), style="R")
        await _reply(ctx, embed=_embed("Quiz retry wait", f"You can try again {retry}."))
        return
    if ctx.author.id in active_quizzes:
        await _reply(ctx, embed=_embed("Quiz already started", "Finish the private quiz message that is already open."))
        return

    if ctx.interaction is not None:
        await _begin_quiz(ctx.interaction)
        return

    view = CodeQuizView(ctx.author.id)
    active_quizzes[ctx.author.id] = view
    try:
        await ctx.author.send(embed=view._embed(), view=view)
    except discord.Forbidden:
        if active_quizzes.get(ctx.author.id) is view:
            active_quizzes.pop(ctx.author.id, None)
        await ctx.reply(
            "I couldn't DM the quiz. Enable DMs from server members and run `.quiz` again.",
            mention_author=False,
        )
    else:
        await ctx.reply("I sent the required beginner quiz to your DMs.", mention_author=False)


@bot.hybrid_command(name="tokens", description="Show your persistent deobfuscation credit balance.")
async def tokens_command(ctx: commands.Context) -> None:
    await _reply(
        ctx,
        embed=_token_embed(ctx.author, token_store.status(ctx.author.id)),
        view=PrintedButtons(ctx.author.id),
    )


@bot.hybrid_command(name="engines", description="List supported deobfuscation engines.")
async def engines_command(ctx: commands.Context) -> None:
    await _reply(
        ctx,
        embed=_embed(
            "Printed Bot · engines",
            "**Full engines:** MoonVeil v1.4.5, Luraph v14.7, v14.8, v14.9, v15, "
            "IronBrew 1, and MoonSec V3 (requires a licensed local install).\n\n"
            "**Static utility:** `/l` or `.l` extracts literal strings and common static "
            "payload encodings without running source code; it does not use credits.\n\n"
            "**Local diagnostics:** restricted Luau behavior and environment traces. "
            "These are partial, are never labeled as full deobfuscation, and do not read "
            "host environment variables or secrets.\n\n"
            "**Not supported yet:** WeAreDevs and Wynfuscate.",
        ),
    )


@bot.hybrid_command(
    name="detect",
    description="Detect a known obfuscator in source or an uploaded file.",
    ignore_extra=True,
)
@app_commands.describe(
    source="Paste Lua/Luau, a public URL, or a static loadstring wrapper.",
    attachment=f"Upload one Lua/Luau file (maximum {MAX_INPUT_MB} MiB).",
)
async def detect_command(
    ctx: commands.Context,
    source: str | None = None,
    attachment: discord.Attachment | None = None,
) -> None:
    started = time.monotonic()
    progress_message: discord.Message | discord.WebhookMessage | None = None
    try:
        raw_source, _ = await _read_command_input(ctx, source, attachment)
        raw_source = unwrap_loadstring(raw_source)
        if raw_source.strip().lower().startswith(("http://", "https://", "loadstring")):
            await _defer(ctx)
            progress_message = await _send_progress(
                ctx,
                _embed(
                    "Resolving source",
                    "Fetching only static public URLs. Lua expressions are never executed.",
                ),
            )
            raw_source, _ = await resolve_fetch_input(raw_source)
        raw_source = sanitize_discord_invites(raw_source)
        detection = await asyncio.to_thread(detect_source, raw_source)
    except (SourceInputError, FetchError) as exc:
        failure = _embed("Couldn't read source", str(exc))
        if progress_message is not None:
            await _edit_progress(progress_message, failure)
        else:
            await _reply(ctx, embed=failure)
        return

    elapsed = time.monotonic() - started
    checked_at = datetime.now(UTC)
    embed = _embed("Obfuscator detection", _normalise_detection(detection))
    embed.add_field(name="Analysis time", value=f"{elapsed:.3f}s", inline=True)
    embed.add_field(
        name="Checked at",
        value=discord.utils.format_dt(checked_at, style="F"),
        inline=True,
    )
    if progress_message is not None:
        await _edit_progress(
            progress_message,
            embed,
            view=PrintedButtons(ctx.author.id),
        )
    else:
        await _reply(ctx, embed=embed, view=PrintedButtons(ctx.author.id))


@bot.hybrid_command(
    name="deobf",
    description="Deobfuscate a supported uploaded Lua/Luau source file.",
    ignore_extra=True,
)
@app_commands.describe(
    source="Paste source or a static loadstring wrapper.",
    attachment=f"Upload one Lua/Luau file (maximum {MAX_INPUT_MB} MiB).",
)
async def deobf_command(
    ctx: commands.Context,
    source: str | None = None,
    attachment: discord.Attachment | None = None,
) -> None:
    try:
        raw_source, filename = await _read_command_input(ctx, source, attachment)
    except SourceInputError as exc:
        await _reply(ctx, embed=_embed("Couldn't read source", str(exc)))
        return

    unwrapped = unwrap_loadstring(raw_source).strip()
    if (
        extract_loadstring_url(raw_source) is not None
        or unwrapped.lower().startswith(("http://", "https://"))
    ):
        await _defer(ctx)
        progress_message = await _send_progress(
            ctx,
            _embed("Resolving loadstring source", "Fetching only the static public URL; Lua expressions are not executed."),
        )
        try:
            raw_source, _ = await resolve_fetch_input(raw_source)
            await _edit_progress(
                progress_message,
                _embed("Source resolved", "Starting engine detection."),
            )
        except FetchError as exc:
            await _edit_progress(progress_message, _embed("Couldn't fetch source", str(exc)))
            return

    await _run_deobfuscation(ctx, raw_source, filename)


@bot.hybrid_command(
    name="l",
    description="Statically extract strings and payloads without executing source.",
    ignore_extra=True,
)
@app_commands.describe(
    source="Paste Lua/Luau source to scan statically.",
    attachment=f"Upload one Lua/Luau file (maximum {MAX_INPUT_MB} MiB).",
)
async def static_dump_command(
    ctx: commands.Context,
    source: str | None = None,
    attachment: discord.Attachment | None = None,
) -> None:
    await _defer(ctx)
    try:
        raw_source, original_filename = await _read_command_input(ctx, source, attachment)
    except SourceInputError as exc:
        await _reply(ctx, embed=_embed("Couldn't read source", str(exc)))
        return

    try:
        result = await asyncio.to_thread(
            build_static_dump,
            raw_source,
            original_filename,
        )
    except StaticDumpError as exc:
        await _reply(ctx, embed=_embed("Static dump couldn't be created", str(exc)))
        return
    except Exception:
        logger.exception("Unexpected static dump failure for user %s.", ctx.author.id)
        await _reply(
            ctx,
            embed=_embed(
                "Static dump failed",
                "The scanner stopped safely. No code was executed and no credits were charged.",
            ),
        )
        return

    title = f"Static dump complete · {result.findings} findings"
    if result.truncated:
        title += " · partial"
    description = (
        "The attached ZIP contains `report.txt` and recovered payload files. "
        "This scan did not execute the uploaded source, and no credits were charged."
    )
    if result.truncated:
        description += " Safety limits were reached; the report marks the extraction as partial."
    output_filename = clean_filename(original_filename, "static-dump").removesuffix(".lua") + ".zip"
    await _deliver_output(
        ctx,
        filename=output_filename,
        payload=result.archive,
        title=title,
        source_text=description,
    )


@bot.hybrid_command(
    name="envlog",
    description="Create a local partial environment log for Luau source.",
    ignore_extra=True,
)
@app_commands.describe(
    source="Paste source, a public URL, or a static loadstring wrapper.",
    attachment=f"Upload one Lua/Luau file (maximum {MAX_INPUT_MB} MiB).",
)
async def environment_log_command(
    ctx: commands.Context,
    source: str | None = None,
    attachment: discord.Attachment | None = None,
) -> None:
    try:
        raw_source, filename = await _read_command_input(ctx, source, attachment)
    except SourceInputError as exc:
        await _reply(ctx, embed=_embed("Couldn't read source", str(exc)))
        return

    unwrapped = unwrap_loadstring(raw_source).strip()
    if (
        extract_loadstring_url(raw_source) is not None
        or unwrapped.lower().startswith(("http://", "https://"))
    ):
        await _defer(ctx)
        progress_message = await _send_progress(
            ctx,
            _embed(
                "Resolving environment-log source",
                "Fetching only the static public URL; source expressions are not executed.",
            ),
        )
        try:
            raw_source, _ = await resolve_fetch_input(raw_source)
            await _edit_progress(
                progress_message,
                _embed("Source resolved", "Starting local environment logging."),
            )
        except FetchError as exc:
            await _edit_progress(progress_message, _embed("Couldn't fetch source", str(exc)))
            return

    await _run_deobfuscation(ctx, raw_source, filename, environment_log=True)


@bot.hybrid_command(
    name="fetch",
    description="Fetch public source code or unwrap a literal loadstring.",
    ignore_extra=True,
)
@app_commands.describe(
    source="Public HTTP(S) URL, Lua/Luau source, or a literal loadstring wrapper.",
    attachment="Optional plain-text file containing the URL or source.",
)
async def fetch_command(
    ctx: commands.Context,
    source: str | None = None,
    attachment: discord.Attachment | None = None,
) -> None:
    started = time.monotonic()
    started_at = datetime.now(UTC)
    progress_message: discord.Message | discord.WebhookMessage | None = None
    try:
        raw_source, _ = await _read_command_input(ctx, source, attachment)
        await _defer(ctx)
        progress_message = await _send_progress(
            ctx,
            _embed(
                "Fetching source",
                "Unwrapping static loadstrings and validating public redirects.",
            ),
        )
        fetch_task = asyncio.create_task(resolve_fetch_input(raw_source))
        while True:
            done, _ = await asyncio.wait({fetch_task}, timeout=4)
            elapsed = time.monotonic() - started
            if done:
                break
            await _edit_progress(
                progress_message,
                _embed(
                    "Fetching source",
                    f"Still validating the URL chain and downloading at most {MAX_INPUT_MB} MiB.\n"
                    f"Elapsed: **{elapsed:.1f}s**.",
                ),
            )
        fetched, origin = await fetch_task
        fetched = sanitize_discord_invites(fetched)
        detection = await asyncio.to_thread(detect_source, fetched)
        run_seconds = time.monotonic() - started
        completed_at = datetime.now(UTC)
        plain = not detection.supported and _looks_like_plain_lua(fetched)
        action_view = None
        if detection.supported or not plain:
            action_view = DeobfuscationActionView(
                ctx.author.id,
                fetched,
                "fetched.lua",
                detection=detection,
                local_trace=not detection.supported,
                output_to_dm=ctx.interaction is None,
            )
        title = "Source fetched · looks readable" if plain else "Source fetched"
        payload = branded_output(fetched, origin)
        delivered = await _deliver_output(
            ctx,
            filename=clean_filename("source", "fetched"),
            payload=payload,
            title=title,
            source_text=fetched,
            detected=detection,
            started_at=started_at,
            completed_at=completed_at,
            run_seconds=run_seconds,
            view=action_view,
        )
        if delivered:
            await _edit_progress(
                progress_message,
                _embed(
                    "Fetch complete",
                    f"Source fetched in **{run_seconds:.2f}s**. "
                    f"Completed {discord.utils.format_dt(completed_at, style='R')}.",
                ),
            )
        else:
            await _edit_progress(
                progress_message,
                _embed(
                    "Source fetched · output not delivered",
                    "Enable DMs from server members, then run the command again.",
                ),
            )
    except (SourceInputError, FetchError) as exc:
        failure = _embed("Couldn't fetch source", str(exc))
        if progress_message is not None:
            await _edit_progress(progress_message, failure)
        else:
            await _reply(ctx, embed=failure)


@bot.hybrid_command(name="grant", description="Grant a user credits (bot owners only).")
@app_commands.describe(
    user="User who receives the credits.",
    amount="Number of credits to add (1–10,000).",
)
async def grant_command(
    ctx: commands.Context,
    user: discord.User,
    amount: int,
) -> None:
    if ctx.author.id not in BOT_OWNERS:
        await _reply(ctx, embed=_embed("Not allowed", "Only the configured bot owners can grant credits."))
        return
    if user.bot:
        await _reply(ctx, embed=_embed("Invalid user", "Credits can only be granted to a person."))
        return
    if amount < 1 or amount > 10_000:
        await _reply(ctx, embed=_embed("Invalid amount", "Choose a number from 1 to 10,000 credits."))
        return

    try:
        total = token_store.grant(user.id, amount)
    except ValueError as exc:
        await _reply(ctx, embed=_embed("Grant not applied", str(exc)))
        return

    embed = _embed(
        "Credits granted",
        f"Added **{amount}** credits for {user.mention}.\n"
        f"Their new balance is **{total} credits**.",
    )
    await _reply(ctx, embed=embed)


@bot.hybrid_command(
    name="shutdown",
    description="Pause bot commands without disconnecting it (bot owners only).",
)
async def shutdown_command(ctx: commands.Context) -> None:
    if ctx.author.id not in BOT_OWNERS:
        await _reply(
            ctx,
            embed=_embed("Not allowed", "Only the configured bot owners can pause bot commands."),
        )
        return
    token_store.set_commands_shutdown(True)
    await _reply(ctx, content="BOT IS SHUT DOWN!")


@bot.hybrid_command(
    name="turnon",
    description="Resume bot commands after /shutdown (bot owners only).",
)
async def turnon_command(ctx: commands.Context) -> None:
    if ctx.author.id not in BOT_OWNERS:
        await _reply(
            ctx,
            embed=_embed("Not allowed", "Only the configured bot owners can turn commands back on."),
        )
        return
    if not token_store.commands_shutdown():
        await _reply(ctx, content="BOT IS ALREADY ON!")
        return
    token_store.set_commands_shutdown(False)
    await _reply(ctx, content="BOT IS TURNED ON!")


@bot.event
async def on_ready() -> None:
    logger.info("Connected as %s (%s).", bot.user, bot.user.id if bot.user else "unknown")


@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError) -> None:
    if isinstance(error, (commands.CommandNotFound, commands.CheckFailure)):
        return
    original = getattr(error, "original", error)
    if isinstance(original, commands.MissingRequiredArgument):
        await _reply(ctx, embed=_embed("Missing input", "Attach a source file or paste code after the command."))
        return
    if isinstance(original, commands.BadArgument):
        await _reply(ctx, embed=_embed("Invalid command input", "Check the user and amount arguments."))
        return
    logger.exception("Command failed.", exc_info=original)
    await _reply(
        ctx,
        embed=_embed("Command failed", "The command failed unexpectedly. Please try again."),
    )


@bot.tree.error
async def on_app_command_error(
    interaction: discord.Interaction,
    error: app_commands.AppCommandError,
) -> None:
    original = getattr(error, "original", error)
    logger.error("Application command failed: %s", original, exc_info=original)
    message = "The command failed unexpectedly. Please try again."
    if isinstance(original, (SourceInputError, FetchError, EngineError)):
        message = str(original)[:1_500]
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


def main() -> None:
    token = os.environ.get("DISCORD_BOT_TOKEN")
    if not token:
        raise SystemExit("DISCORD_BOT_TOKEN is missing; add it as a Replit Secret.")
    bot.run(token, log_handler=None)


if __name__ == "__main__":
    main()