from __future__ import annotations

import base64
import binascii
import hashlib
import io
import re
import zipfile
from dataclasses import dataclass
from pathlib import PurePath
from urllib.parse import unquote_to_bytes

from config import MAX_INPUT_BYTES, MAX_OUTPUT_BYTES

MAX_DUMP_FINDINGS = 250
MAX_DUMP_PAYLOAD_BYTES = 20 * 1_048_576
MAX_DUMP_SCAN_BYTES = MAX_INPUT_BYTES * 4
MAX_DUMP_DEPTH = 2
MAX_SCAN_LITERALS = 5_000
MAX_SCAN_CALLS = 2_000

_CHAR_CALL = re.compile(r"\bstring\s*\.\s*char\s*\(([^()]*)\)", re.IGNORECASE)
_NUMBERS = re.compile(r"\s*(?:0[xX][0-9A-Fa-f]+|\d+)(?:\s*,\s*(?:0[xX][0-9A-Fa-f]+|\d+))*\s*")
_NUMERIC_TABLE = re.compile(r"\{\s*(\d+(?:\s*,\s*\d+){7,})\s*,?\s*\}")
_HEX = re.compile(rb"(?:0[xX])?[0-9A-Fa-f]{16,}")
_BASE64 = re.compile(rb"[A-Za-z0-9+/_-]{24,}={0,2}")
_PERCENT_BYTES = re.compile(rb"%[0-9A-Fa-f]{2}")


class StaticDumpError(ValueError):
    pass


@dataclass(frozen=True)
class StaticDumpResult:
    archive: bytes
    findings: int
    truncated: bool


@dataclass(frozen=True)
class _Literal:
    start: int
    end: int
    data: bytes


@dataclass(frozen=True)
class _Finding:
    kind: str
    origin: str
    data: bytes


def _long_bracket_open(source: str, start: int) -> tuple[int, str] | None:
    if start >= len(source) or source[start] != "[":
        return None
    cursor = start + 1
    while cursor < len(source) and source[cursor] == "=":
        cursor += 1
    if cursor >= len(source) or source[cursor] != "[":
        return None
    return cursor + 1, "]" + source[start + 1 : cursor] + "]"


def _read_long_bracket(source: str, start: int) -> tuple[bytes, int] | None:
    opened = _long_bracket_open(source, start)
    if opened is None:
        return None
    content_start, closing = opened
    close_at = source.find(closing, content_start)
    if close_at < 0:
        content_end = len(source)
        end = len(source)
    else:
        content_end = close_at
        end = close_at + len(closing)
    content = source[content_start:content_end]
    if content.startswith("\r\n"):
        content = content[2:]
    elif content.startswith(("\n", "\r")):
        content = content[1:]
    return content.encode("utf-8", errors="replace"), end


def _read_quoted(source: str, start: int) -> tuple[bytes, int]:
    quote = source[start]
    output = bytearray()
    cursor = start + 1
    escapes = {
        "a": b"\a",
        "b": b"\b",
        "f": b"\f",
        "n": b"\n",
        "r": b"\r",
        "t": b"\t",
        "v": b"\v",
        "\\": b"\\",
        "'": b"'",
        '"': b'"',
    }
    while cursor < len(source):
        char = source[cursor]
        cursor += 1
        if char == quote:
            return bytes(output), cursor
        if char != "\\" or cursor >= len(source):
            output.extend(char.encode("utf-8", errors="replace"))
            continue

        escaped = source[cursor]
        cursor += 1
        if escaped in escapes:
            output.extend(escapes[escaped])
        elif escaped == "z":
            while cursor < len(source) and source[cursor].isspace():
                cursor += 1
        elif escaped == "x" and cursor + 1 < len(source):
            digits = source[cursor : cursor + 2]
            if re.fullmatch(r"[0-9A-Fa-f]{2}", digits):
                output.append(int(digits, 16))
                cursor += 2
            else:
                output.extend(b"x")
        elif escaped == "u" and cursor < len(source) and source[cursor] == "{":
            close_at = source.find("}", cursor + 1)
            digits = source[cursor + 1 : close_at] if close_at >= 0 else ""
            try:
                codepoint = int(digits, 16)
                if codepoint <= 0x10FFFF and not 0xD800 <= codepoint <= 0xDFFF:
                    output.extend(chr(codepoint).encode("utf-8"))
                    cursor = close_at + 1
                else:
                    output.extend(b"u")
            except ValueError:
                output.extend(b"u")
        elif escaped.isdigit():
            end = cursor
            while end < min(len(source), cursor + 2) and source[end].isdigit():
                end += 1
            digits = escaped + source[cursor:end]
            value = int(digits, 10)
            if value <= 255:
                output.append(value)
            else:
                output.extend(("\\" + digits).encode("ascii"))
            cursor = end
        elif escaped in {"\n", "\r"}:
            if escaped == "\r" and cursor < len(source) and source[cursor] == "\n":
                cursor += 1
            output.extend(b"\n")
        else:
            output.extend(escaped.encode("utf-8", errors="replace"))
    return bytes(output), cursor


def _scan_source(source: str) -> tuple[list[_Literal], list[tuple[int, int]], bool]:
    literals: list[_Literal] = []
    code_spans: list[tuple[int, int]] = []
    truncated = False
    cursor = 0
    code_start = 0

    while cursor < len(source):
        if source.startswith("--", cursor):
            if code_start < cursor:
                code_spans.append((code_start, cursor))
            long_string = _read_long_bracket(source, cursor + 2)
            if long_string is not None:
                _, cursor = long_string
            else:
                newline = source.find("\n", cursor + 2)
                cursor = len(source) if newline < 0 else newline + 1
            code_start = cursor
            continue

        if source[cursor] in {"'", '"'}:
            if code_start < cursor:
                code_spans.append((code_start, cursor))
            start = cursor
            value, cursor = _read_quoted(source, cursor)
            if len(literals) < MAX_SCAN_LITERALS:
                literals.append(_Literal(start, cursor, value))
            else:
                truncated = True
            code_start = cursor
            continue

        if source[cursor] == "[":
            long_string = _read_long_bracket(source, cursor)
            if long_string is not None:
                if code_start < cursor:
                    code_spans.append((code_start, cursor))
                start = cursor
                value, cursor = long_string
                if len(literals) < MAX_SCAN_LITERALS:
                    literals.append(_Literal(start, cursor, value))
                else:
                    truncated = True
                code_start = cursor
                continue
        cursor += 1

    if code_start < len(source):
        code_spans.append((code_start, len(source)))
    return literals, code_spans, truncated


def _static_generated_values(
    source: str,
    code_spans: list[tuple[int, int]],
) -> tuple[list[tuple[str, int, bytes]], bool]:
    values: list[tuple[str, int, bytes]] = []
    truncated = False
    calls_seen = 0
    for start, end in code_spans:
        code = source[start:end]
        for match in _CHAR_CALL.finditer(code):
            calls_seen += 1
            if calls_seen > MAX_SCAN_CALLS:
                return values, True
            arguments = match.group(1)
            if not _NUMBERS.fullmatch(arguments):
                continue
            pieces = [piece.strip() for piece in arguments.split(",")]
            if not pieces or len(pieces) > 100_000:
                continue
            try:
                numbers = [
                    int(piece, 16) if piece.lower().startswith("0x") else int(piece, 10)
                    for piece in pieces
                ]
            except ValueError:
                continue
            if all(0 <= number <= 255 for number in numbers):
                values.append(
                    ("string.char", start + match.start(), bytes(numbers))
                )

        for match in _NUMERIC_TABLE.finditer(code):
            calls_seen += 1
            if calls_seen > MAX_SCAN_CALLS:
                return values, True
            pieces = [piece.strip() for piece in match.group(1).split(",")]
            try:
                numbers = [int(piece, 10) for piece in pieces]
            except ValueError:
                continue
            if len(numbers) >= 8 and all(0 <= number <= 255 for number in numbers):
                values.append(("numeric-table", start + match.start(), bytes(numbers)))

    return values, truncated


def _decode_candidates(data: bytes) -> list[tuple[str, bytes]]:
    candidates: list[tuple[str, bytes]] = []
    compact = re.sub(rb"\s+", b"", data)
    if len(compact) >= 24 and _BASE64.fullmatch(compact):
        padded = compact + b"=" * ((-len(compact)) % 4)
        try:
            decoded = base64.b64decode(padded, altchars=b"-_", validate=True)
        except (binascii.Error, ValueError):
            pass
        else:
            if len(decoded) >= 16 and decoded != data:
                candidates.append(("base64", decoded))

    hex_value = re.sub(rb"[\s:_-]", b"", data.strip())
    if hex_value[:2].lower() == b"0x":
        hex_value = hex_value[2:]
    if len(hex_value) >= 16 and len(hex_value) % 2 == 0 and _HEX.fullmatch(hex_value):
        try:
            decoded = bytes.fromhex(hex_value.decode("ascii"))
        except (ValueError, UnicodeDecodeError):
            pass
        else:
            if decoded != data:
                candidates.append(("hex", decoded))

    percent_count = len(_PERCENT_BYTES.findall(data))
    if percent_count >= 4:
        decoded = unquote_to_bytes(data.decode("latin-1"))
        if decoded != data:
            candidates.append(("percent-encoding", decoded))
    return candidates


def _is_text_payload(data: bytes) -> bool:
    if not data or b"\x00" in data:
        return False
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return False
    if not text:
        return False
    printable = sum(char.isprintable() or char in "\r\n\t" for char in text)
    return printable / len(text) >= 0.82


def _safe_kind(kind: str) -> str:
    return re.sub(r"[^a-z0-9_-]+", "_", kind.lower()).strip("_") or "payload"


def _preview(data: bytes) -> str:
    if _is_text_payload(data):
        text = data.decode("utf-8-sig", errors="replace")
        return repr(text[:160])
    return data[:64].hex() + ("…" if len(data) > 64 else "")


def build_static_dump(source: str, filename: str = "source.lua") -> StaticDumpResult:
    """Extract literal and statically decodable data without evaluating the source."""
    findings: dict[tuple[str, bytes], _Finding] = {}
    total_payload_bytes = 0
    total_scanned_bytes = 0
    truncated = False
    visited_layers: set[bytes] = set()
    pending: list[tuple[str, str, int]] = [(source, "uploaded source", 0)]

    def add_finding(kind: str, origin: str, data: bytes) -> bool:
        nonlocal total_payload_bytes, truncated
        if not data:
            return False
        key = (kind, data)
        if key in findings:
            return False
        if len(findings) >= MAX_DUMP_FINDINGS:
            truncated = True
            return False
        if total_payload_bytes + len(data) > MAX_DUMP_PAYLOAD_BYTES:
            truncated = True
            return False
        findings[key] = _Finding(kind, origin, data)
        total_payload_bytes += len(data)
        return True

    while pending:
        layer_source, origin, depth = pending.pop()
        source_bytes = layer_source.encode("utf-8", errors="replace")
        digest = hashlib.sha256(source_bytes).digest()
        if digest in visited_layers:
            continue
        visited_layers.add(digest)
        total_scanned_bytes += len(source_bytes)
        if total_scanned_bytes > MAX_DUMP_SCAN_BYTES:
            truncated = True
            break

        literals, code_spans, literal_truncated = _scan_source(layer_source)
        truncated = truncated or literal_truncated
        roots: list[tuple[str, int, bytes]] = [
            ("string-literal", item.start, item.data)
            for item in literals
            if item.data
        ]

        chain: list[_Literal] = []
        for item in literals:
            if chain and re.fullmatch(
                r"\s*\.\.\s*",
                layer_source[chain[-1].end : item.start],
            ):
                chain.append(item)
                continue
            if len(chain) > 1:
                roots.append(
                    ("literal-concat", chain[0].start, b"".join(part.data for part in chain))
                )
            chain = [item]
        if len(chain) > 1:
            roots.append(
                ("literal-concat", chain[0].start, b"".join(part.data for part in chain))
            )

        generated, generated_truncated = _static_generated_values(layer_source, code_spans)
        roots.extend(generated)
        truncated = truncated or generated_truncated

        nested_payloads: list[tuple[str, str, int]] = []
        for kind, offset, data in roots:
            location = f"{origin} at character {offset}"
            added = add_finding(kind, location, data)
            if not added and len(findings) >= MAX_DUMP_FINDINGS:
                break
            for encoding, decoded in _decode_candidates(data):
                decoded_origin = f"{encoding} decoded from {location}"
                if add_finding(encoding, decoded_origin, decoded):
                    if depth < MAX_DUMP_DEPTH and _is_text_payload(decoded):
                        nested_payloads.append(
                            (
                                decoded.decode("utf-8-sig", errors="replace"),
                                decoded_origin,
                                depth + 1,
                            )
                        )
            if len(findings) >= MAX_DUMP_FINDINGS:
                truncated = True
                break

        if len(pending) + len(nested_payloads) > 128:
            nested_payloads = nested_payloads[: max(0, 128 - len(pending))]
            truncated = True
        pending.extend(reversed(nested_payloads))

    report_lines = [
        "Printed Bot — static source dump",
        f"Input: {PurePath(filename).name}",
        "Safety: source code was not executed; no network or host environment was accessed.",
        f"Findings: {len(findings)}",
        f"Truncated by safety limits: {'yes' if truncated else 'no'}",
        "",
    ]

    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for index, finding in enumerate(findings.values(), start=1):
            suffix = "txt" if _is_text_payload(finding.data) else "bin"
            relative_path = f"payloads/{index:03d}_{_safe_kind(finding.kind)}.{suffix}"
            report_lines.extend(
                [
                    f"[{index:03d}] {finding.kind}",
                    f"Origin: {finding.origin}",
                    f"Size: {len(finding.data)} bytes",
                    f"File: {relative_path}",
                    f"Preview: {_preview(finding.data)}",
                    "",
                ]
            )
            bundle.writestr(relative_path, finding.data)

        if not findings:
            report_lines.append("No static string or payload candidates were found.")
        bundle.writestr("report.txt", "\n".join(report_lines).encode("utf-8"))

    archive = output.getvalue()
    if len(archive) > MAX_OUTPUT_BYTES:
        raise StaticDumpError(
            f"The extracted bundle exceeds the {MAX_OUTPUT_BYTES // 1_048_576} MiB output limit. "
            "Use a smaller source file or split the input."
        )
    return StaticDumpResult(archive, len(findings), truncated)