from __future__ import annotations

import os
import re
import signal
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from config import (
    ENGINE_DIR,
    ENGINE_TIMEOUT_SECONDS,
    MAX_INPUT_MB,
    MAX_OUTPUT_BYTES,
    MOONSEC_DIR,
    MOONVEIL_DIR,
)

_LURAPH_HEADER = re.compile(
    r"Luraph\s+Obfuscator\s+v\s*(\d+(?:\.\d+)?)",
    re.IGNORECASE,
)
_SUPPORTED_V14 = {"14.7", "14.8", "14.9"}
_MOONVEIL_HEADER = re.compile(
    r"MoonVeil(?:\s+Obfuscator)?\s+v?1\.4\.5\b",
    re.IGNORECASE,
)
_MOONSEC_V3_HEADER = re.compile(
    r"This file was protected with MoonSec V3\b",
    re.IGNORECASE,
)
_PARTIAL_OUTPUT_MARKER = (
    "-- printed bot result: partial trace-assisted reconstruction; not full deobfuscation."
)
_TRACE_ONLY_MARKERS = (
    "-- local behavior trace only; not a complete deobfuscation.",
    "-- yeah this ran at runtime and its gonna be shit",
    "-- not gonna be full",
)
_TRACE_ERROR = re.compile(
    r"^\s*--\s*run status:\s*script error:\s*([^\r\n]+)",
    re.IGNORECASE | re.MULTILINE,
)
_INCOMPLETE_OUTPUT_MARKERS = (
    "unresolved luraph runtime helper",
    "unresolved native/runtime closure",
    "devirtualizer failed so fuck off",
    "thiswasranatruntimeexpectittobeshit",
    "lph run time be shit pls",
)


@dataclass(frozen=True)
class Detection:
    name: str
    confidence: float
    engine: str | None
    note: str = ""
    partial: bool = False

    @property
    def supported(self) -> bool:
        return self.engine is not None


class EngineError(RuntimeError):
    pass


def _validate_engine_output(output: bytes, *, allow_trace_errors: bool = False) -> bool:
    """Reject placeholders; identify trace-only output and optionally allow trace errors."""
    text = output.decode("utf-8-sig", errors="replace").lower()
    if any(marker in text for marker in _INCOMPLETE_OUTPUT_MARKERS):
        raise EngineError(
            "The engine left unresolved runtime-helper stubs, so this result is incomplete. "
            "No output file was sent; reserved credits are returned."
        )
    trace_only = any(marker in text for marker in _TRACE_ONLY_MARKERS)
    trace_error = _TRACE_ERROR.search(text)
    if trace_only and trace_error and not allow_trace_errors:
        detail = trace_error.group(1).strip()[:240]
        raise EngineError(
            "The engine returned only a runtime trace, and the script stopped with an error "
            f"before a full deobfuscation was recovered: {detail}. "
            "No output file was sent; reserved credits are returned."
        )
    return trace_only or _PARTIAL_OUTPUT_MARKER in text


def _trace_quality_note(output: bytes) -> str:
    text = output.decode("utf-8-sig", errors="replace")
    match = _TRACE_ERROR.search(text)
    if match:
        return f"Local trace stopped on a script error: {match.group(1).strip()[:240]}"
    return "The engine returned a behavior trace, not a full deobfuscation."


def detect_source(source: str) -> Detection:
    """Identify engines actually present in the supplied source bundle."""
    if _MOONSEC_V3_HEADER.search(source[:64_000]):
        return Detection("MoonSec V3", 1.0, "moonsec_v3")

    if _MOONVEIL_HEADER.search(source[:4096]):
        return Detection("MoonVeil v1.4.5", 1.0, "moonveil145")

    header = _LURAPH_HEADER.search(source[:4096])
    if header:
        version = header.group(1)
        normalized = "15" if version.startswith("15.") else version
        if normalized in _SUPPORTED_V14:
            return Detection(f"Luraph v{normalized}", 1.0, normalized)
        if normalized == "15":
            return Detection("Luraph v15", 1.0, "15")
        return Detection(
            f"Luraph v{version}",
            1.0,
            None,
            "This version is not included in the supplied engine.",
        )

    head = source.lstrip("\ufeff \t\r\n")[:20_000]
    if head.startswith("local init = (function(...") and "return({" in head:
        return Detection(
            "Luraph v14.8 (likely; version banner not found)",
            0.75,
            "14.8",
            "The version was inferred from the known v14.8 layout.",
        )

    folded = source[:50_000].lower()
    if "wynfuscate" in folded:
        return Detection(
            "Wynfuscate",
            0.9,
            None,
            "Wynfuscate support is coming soon.",
        )
    if "wearedevs" in folded or "we are devs" in folded:
        return Detection(
            "WeAreDevs",
            0.9,
            None,
            "WeAreDevs support is coming soon.",
        )

    try:
        engine_path = str(ENGINE_DIR)
        if engine_path not in sys.path:
            sys.path.insert(0, engine_path)
        import obfuscators

        plugin, confidence = obfuscators.detect(source)
    except Exception:
        return Detection("Unknown / unrecognized", 0.0, None)

    if plugin.name == "luraph_v15":
        return Detection("Luraph v15", confidence, "15")
    if plugin.name == "ironbrew1":
        return Detection("IronBrew 1", confidence, "ironbrew1")
    return Detection(
        "Unknown / unrecognized Luau",
        max(0.0, min(float(confidence), 1.0)),
        None,
        "The supplied engine has no full deobfuscator for this signature.",
    )


def _resource_limits() -> None:
    if os.name != "posix":
        return
    import resource

    cpu_limit = ENGINE_TIMEOUT_SECONDS + 20
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_limit, cpu_limit))
    resource.setrlimit(resource.RLIMIT_AS, (3 * 1024**3, 3 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2, 64 * 1024**2))
    resource.setrlimit(resource.RLIMIT_NOFILE, (128, 128))


def _terminate_process_tree(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    try:
        if os.name == "posix":
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
    except ProcessLookupError:
        pass
    process.communicate()


def _command_for(
    engine: str,
    input_path: Path,
    output_path: Path,
    runtime_path: Path | None = None,
) -> list[str]:
    if engine == "moonveil145":
        if runtime_path is None:
            raise EngineError("MoonVeil requires the bundled Luau runtime.")
        return [
            sys.executable,
            "-m",
            "moonveil",
            "decompile",
            str(input_path),
            "-o",
            str(output_path),
            "--luau",
            str(runtime_path),
            "--timeout",
            str(ENGINE_TIMEOUT_SECONDS - 10),
        ]

    if engine == "moonsec_v3":
        if MOONSEC_DIR is None:
            raise EngineError(
                "MoonSec V3 is detected, but its source is not bundled. "
                "Set MOONSEC_DIR to a locally installed, licensed MoonSec V3 source tree."
            )
        cli = MOONSEC_DIR / "moonsec" / "Lua" / "cli.lua"
        if not cli.is_file():
            raise EngineError(
                "MoonSec V3 was detected, but MOONSEC_DIR does not contain "
                "moonsec/Lua/cli.lua."
            )
        lua_binary = os.environ.get("LUA_BINARY") or shutil.which("lua")
        if not lua_binary:
            raise EngineError(
                "MoonSec V3 needs a Lua interpreter. Install Lua or set LUA_BINARY "
                "to its executable path."
            )
        return [lua_binary, str(cli), str(input_path), str(output_path)]

    if engine in _SUPPORTED_V14:
        cli = ENGINE_DIR / "cli.py"
        return [
            sys.executable,
            str(cli),
            str(input_path),
            "--engine",
            engine,
            "--timeout",
            str(ENGINE_TIMEOUT_SECONDS - 10),
            "--output",
            str(output_path),
        ]

    cli = ENGINE_DIR / "deob.py"
    args = [
        sys.executable,
        str(cli),
        str(input_path),
        "--timeout",
        str(ENGINE_TIMEOUT_SECONDS - 10),
        "--budget",
        "25",
        "--no-pypy",
        "-o",
        str(output_path),
    ]
    if engine == "ironbrew1":
        args.extend(["--obfuscator", "ironbrew1"])
    elif engine == "generic":
        args.extend(["--obfuscator", "generic"])
    return args


def _run_luau_parser(
    source_path: Path,
    job_dir: Path,
    child_env: dict[str, str],
) -> subprocess.CompletedProcess[str]:
    parser = ENGINE_DIR / "bin" / ("luau-ast.exe" if os.name == "nt" else "luau-ast")
    if not parser.is_file():
        raise EngineError("The built-in Luau output validator is missing.")
    try:
        return subprocess.run(
            [str(parser), str(source_path)],
            cwd=job_dir,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=child_env,
            timeout=15,
            preexec_fn=_resource_limits if os.name == "posix" else None,
        )
    except subprocess.TimeoutExpired as exc:
        raise EngineError("The Luau parser timed out; no file was sent.") from exc
    except OSError as exc:
        raise EngineError(f"Could not run the Luau parser: {exc}") from exc


def _parse_failed(result: subprocess.CompletedProcess[str]) -> bool:
    return (
        result.returncode != 0
        or "parse errors were encountered" in (result.stderr or "").lower()
    )


def _validate_luau_input(input_path: Path, job_dir: Path, child_env: dict[str, str]) -> None:
    result = _run_luau_parser(input_path, job_dir, child_env)
    if _parse_failed(result):
        details = (result.stderr or "").strip()[-500:]
        suffix = f"\n```text\n{details}\n```" if details else ""
        raise EngineError(
            "The uploaded source is malformed or truncated. Upload the complete original "
            f"Lua/Luau file; no output was sent.{suffix}"
        )


def _validate_luau_output(output_path: Path, job_dir: Path, child_env: dict[str, str]) -> None:
    result = _run_luau_parser(output_path, job_dir, child_env)
    if _parse_failed(result):
        details = (result.stderr or "").strip()[-500:]
        suffix = f"\n```text\n{details}\n```" if details else ""
        raise EngineError(
            f"The engine returned output that is not valid Luau; no file was sent.{suffix}"
        )


def deobfuscate_sync(
    source: str,
    filename: str,
    *,
    allow_generic_trace: bool = False,
    environment_log: bool = False,
) -> tuple[bytes, Detection, float]:
    detection = detect_source(source)
    generic_trace = environment_log or (not detection.supported and allow_generic_trace)
    if not detection.supported and not generic_trace:
        raise EngineError(
            detection.note
            or f"{detection.name} is detected, but this bot does not have a full deobfuscator for it."
        )

    runtime = ENGINE_DIR / "bin" / ("luau.exe" if os.name == "nt" else "luau")
    if not runtime.is_file():
        raise EngineError(
            "The Luau runtime is not built yet. Run "
            "`python services/printed-bot/engine/deobf/build_luau.py --portable` first."
        )

    with tempfile.TemporaryDirectory(prefix="printed-job-") as temporary:
        job_dir = Path(temporary)
        extension = Path(filename).suffix.lower()
        if extension not in {".lua", ".luau", ".txt"}:
            extension = ".lua"
        input_path = job_dir / f"input{extension}"
        output_path = job_dir / "deobfuscated.lua"
        input_path.write_text(source, encoding="utf-8", newline="")

        child_env = {
            "PATH": os.environ.get("PATH", ""),
            "HOME": str(job_dir),
            "TMPDIR": str(job_dir),
            "TMP": str(job_dir),
            "TEMP": str(job_dir),
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "PYTHONNOUSERSITE": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
        }
        engine = "generic" if generic_trace else detection.engine or ""
        if engine == "moonveil145":
            if not MOONVEIL_DIR.is_dir():
                raise EngineError("The bundled MoonVeil v1.4.5 engine files are missing.")
            child_env["PYTHONPATH"] = str(MOONVEIL_DIR)
        # The analysis child does not need bot credentials or Replit secrets.
        if os.environ.get("LD_LIBRARY_PATH"):
            child_env["LD_LIBRARY_PATH"] = os.environ["LD_LIBRARY_PATH"]
        _validate_luau_input(input_path, job_dir, child_env)
        try:
            engine_started = time.monotonic()
            process = subprocess.Popen(
                _command_for(engine, input_path, output_path, runtime),
                cwd=job_dir,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=child_env,
                start_new_session=(os.name == "posix"),
                preexec_fn=_resource_limits if os.name == "posix" else None,
            )
            try:
                stdout, stderr = process.communicate(timeout=ENGINE_TIMEOUT_SECONDS)
                engine_run_seconds = time.monotonic() - engine_started
            except subprocess.TimeoutExpired as exc:
                _terminate_process_tree(process)
                raise EngineError("Deobfuscation exceeded the 120-second time limit.") from exc
        except OSError as exc:
            raise EngineError(f"Could not start the deobfuscation engine: {exc}") from exc

        if process.returncode != 0:
            details = (stderr or stdout or "").strip()
            if "the luraph lift contains unresolved runtime helpers" in details.lower():
                raise EngineError(
                    "This Luraph input still uses runtime helpers the bundled engine could not "
                    "resolve. I did not send incomplete output, and your reserved credits were refunded."
                )
            lowered_details = details.lower()
            if any(
                marker in lowered_details
                for marker in (
                    "input is truncated or incomplete",
                    "unfinished source construct",
                    "malformed string",
                    "did you forget to finish it",
                )
            ):
                raise EngineError(
                    "This upload appears truncated or malformed. Please upload the complete "
                    "original source file; no output was sent and reserved credits are returned."
                )
            details = details[-1_200:] if details else "The engine exited without an error message."
            details = details.replace(str(job_dir), "<analysis>")
            raise EngineError(f"The engine could not deobfuscate this file.\n```text\n{details}\n```")
        if not output_path.is_file():
            details = (stderr or stdout or "").strip()
            details = details[-1_200:] if details else "The engine returned no output file."
            raise EngineError(f"The engine produced no output.\n```text\n{details}\n```")

        output = output_path.read_bytes()
        output = output.replace(str(job_dir).encode("utf-8"), b"<analysis>")
        output = output.replace(str(job_dir).replace("\\", "/").encode("utf-8"), b"<analysis>")
        if not output:
            raise EngineError("The engine returned an empty file.")
        partial_output = _validate_engine_output(
            output,
            allow_trace_errors=generic_trace,
        )
        if len(output) > MAX_OUTPUT_BYTES - 1024:
            raise EngineError(
                f"The deobfuscated output is too large to brand and send "
                f"({MAX_OUTPUT_BYTES // 1_048_576} MiB maximum)."
            )
        _validate_luau_output(output_path, job_dir, child_env)
        if output.strip() == source.encode("utf-8").strip():
            raise EngineError("The engine returned the original source unchanged; no file was sent.")
        if generic_trace:
            trace_text = output.decode("utf-8", errors="replace")
            statements = [
                line
                for line in trace_text.splitlines()
                if line.strip() and not line.lstrip().startswith("--")
            ]
            if not statements:
                raise EngineError(
                    "The local behavior trace did not capture any executed statements; "
                    "no file was sent and your credits were refunded."
                )
            output = (
                b"-- Partial local behavior trace only; this is not full deobfuscation.\n\n"
                + output
            )
        actual_detection = detection
        if environment_log:
            actual_detection = Detection(
                detection.name,
                detection.confidence,
                detection.engine or "generic",
                _trace_quality_note(output),
                partial=True,
            )
        elif partial_output:
            actual_detection = Detection(
                detection.name,
                detection.confidence,
                detection.engine,
                _trace_quality_note(output),
                partial=True,
            )
        return output, actual_detection, engine_run_seconds